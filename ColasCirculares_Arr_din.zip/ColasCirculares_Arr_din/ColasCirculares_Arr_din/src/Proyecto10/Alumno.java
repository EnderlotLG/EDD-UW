/*}
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Proyecto10;

/**
 *
 * @author crise
 */
public class Alumno {

    private int Ant;
    private String NC;
    private String Nom;
    private String Dom;
    private String Tel;
    private String Email;
    private int Sig;

    public int getAnt() {
        return Ant;
    }

    public void setAnt(int Ant) {
        this.Ant = Ant;
    }

    public String getNC() {
        return NC;
    }

    public void setNC(String NC) {
        this.NC = NC;
    }

    public String getNom() {
        return Nom;
    }

    public void setNom(String Nom) {
        this.Nom = Nom;
    }

    public String getDom() {
        return Dom;
    }

    public void setDom(String Dom) {
        this.Dom = Dom;
    }

    public String getTel() {
        return Tel;
    }

    public void setTel(String Tel) {
        this.Tel = Tel;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public int getSig() {
        return Sig;
    }

    public void setSig(int Sig) {
        this.Sig = Sig;
    }

    public Alumno(int Ant, String NC, String Nom, String Dom, String Tel, String Email, int Sig) {
        this.Ant = Ant;
        this.NC = NC;
        this.Nom = Nom;
        this.Dom = Dom;
        this.Tel = Tel;
        this.Email = Email;
        this.Sig = Sig;
    }

    public Alumno() {
    }
}
