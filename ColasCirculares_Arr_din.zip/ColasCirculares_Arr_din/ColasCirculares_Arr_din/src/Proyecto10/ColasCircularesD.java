
package Proyecto10;
import java.util.ArrayList;
/**
 *
 * @author fdogs
 */
public class ColasCircularesD {
   private ArrayList<Alumno> Lista;
    private int Frente;
    private int Final;
    
    public ColasCircularesD() {
        this.Lista = new ArrayList<>();
        this.Frente = -1;
        this.Final = -1;
    }
    
    public int getFrente() {
        return Frente;
    }
    
    public void setFrente(int Frente) {
        this.Frente = Frente;
    }
    
    public int getFinal() {
        return Final;
    }
    
    public void setFinal(int Final) {
        this.Final = Final;
    }
    
    public int getTamanio() {
        return Lista.size();
    }
    
    public boolean ColaVacia() {
        return Lista.isEmpty();
    }
    
    public void Inserta(Alumno Nuevo) {
        if (ColaVacia()) {
            Frente = 0;
            Final = 0;
            Nuevo.setAnt(0);
            Nuevo.setSig(0);
            Lista.add(Nuevo);
        } else {
            int NuevoFinal = Lista.size();
            int Anterior = Final;
            
            Nuevo.setAnt(Anterior);
            Nuevo.setSig(Frente);
            
            Lista.get(Anterior).setSig(NuevoFinal);
            Lista.get(Frente).setAnt(NuevoFinal);
            
            Lista.add(Nuevo);
            Final = NuevoFinal;
        }
        
        System.out.println("Alumno insertado correctamente");
    }
    
    public void Elimina() {
        if (ColaVacia()) {
            System.out.println("Error: No se puede eliminar, la cola está vacía");
            return;
        }
        
        System.out.println("Eliminando alumno: " + Lista.get(Frente).getNom());
        
        if (Lista.size() == 1) {
            Lista.clear();
            Frente = -1;
            Final = -1;
        } else {
            int NuevoFrente = Lista.get(Frente).getSig();
            int UltimoPos = Lista.get(Frente).getAnt();
            
            // Actualizar enlaces
            Lista.get(NuevoFrente).setAnt(UltimoPos);
            Lista.get(UltimoPos).setSig(NuevoFrente);
            
            // Eliminar el elemento del frente
            Lista.remove(Frente);
            
            // Reajustar índices
            if (NuevoFrente > Frente) {
                NuevoFrente--;
            }
            if (UltimoPos > Frente) {
                UltimoPos--;
            }
            
            // Actualizar todos los índices en la lista
            for (int i = 0; i < Lista.size(); i++) {
                int ant = Lista.get(i).getAnt();
                int sig = Lista.get(i).getSig();
                
                if (ant > Frente) {
                    Lista.get(i).setAnt(ant - 1);
                }
                if (sig > Frente) {
                    Lista.get(i).setSig(sig - 1);
                }
            }
            
            Frente = NuevoFrente;
            Final = UltimoPos;
        }
    }
    
    public void ListarDerecha() {
        if (ColaVacia()) {
            System.out.println("La cola está vacía");
            return;
        }
        
        System.out.println("\n=== Listado de Derecha (Frente -> Final) ===");
        System.out.println(String.format("%-5s %-15s %-20s %-25s %-15s %-25s %-5s", 
            "Ant", "No. Control", "Nombre", "Domicilio", "Teléfono", "Email", "Sig"));
        System.out.println("=".repeat(120));
        
        int Pos = Frente;
        int Visitados = 0;
        
        do {
            Alumno actual = Lista.get(Pos);
            System.out.print(String.format("%-5d ", actual.getAnt()));
            System.out.print(actual.toString());
            System.out.println(String.format(" %-5d", actual.getSig()));
            
            Pos = actual.getSig();
            Visitados++;
        } while (Visitados < Lista.size());
        
        System.out.println("=".repeat(120));
        System.out.println("Total de alumnos: " + Lista.size());
    }
    
    public void ListarIzquierda() {
        if (ColaVacia()) {
            System.out.println("La cola está vacía");
            return;
        }
        
        System.out.println("\n=== Listado de Izquierda (Final -> Frente) ===");
        System.out.println(String.format("%-5s %-15s %-20s %-25s %-15s %-25s %-5s", 
            "Ant", "No. Control", "Nombre", "Domicilio", "Teléfono", "Email", "Sig"));
        System.out.println("=".repeat(120));
        
        int Pos = Final;
        int Visitados = 0;
        
        do {
            Alumno actual = Lista.get(Pos);
            System.out.print(String.format("%-5d ", actual.getAnt()));
            System.out.print(actual.toString());
            System.out.println(String.format(" %-5d", actual.getSig()));
            
            Pos = actual.getAnt();
            Visitados++;
        } while (Visitados < Lista.size());
        
        System.out.println("=".repeat(120));
        System.out.println("Total de alumnos: " + Lista.size());
    } 
}
