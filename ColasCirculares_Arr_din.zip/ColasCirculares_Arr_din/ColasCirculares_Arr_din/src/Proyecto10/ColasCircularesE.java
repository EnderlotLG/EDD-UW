package Proyecto10;

/**
 *
 * @author crise
 */
public class ColasCircularesE {
private Alumno[] Arr;
    private int Frente;
    private int Final;
    private int Tmax;
    private int Contador; // Para saber cuántos elementos hay
    
    public ColasCircularesE(int Frente, int Final, int Tmax) {
        this.Frente = Frente;
        this.Final = Final;
        this.Tmax = Tmax;
        this.Contador = 0;
        this.Arr = new Alumno[Tmax]; // Arreglo del tamaño especificado
        for (int j = 0; j < Tmax; j++) {
            Arr[j] = new Alumno();
        }
    }
    
    public int getFrente() {
        return Frente;
    }
    
    public void setFrente(int Frente) {
        this.Frente = Frente;
    }
    
    public int getFinal() {
        return Final;
    }
    
    public void setFinal(int Final) {
        this.Final = Final;
    }
    
    public int getTmax() {
        return Tmax;
    }
    
    public void setTmax(int Tmax) {
        this.Tmax = Tmax;
    }
    
    public boolean ColaVacia() {
        return Contador == 0;
    }
    
    public boolean ColaLlena() {
        return Contador == Tmax;
    }
    
    public void Inserta(Alumno Nuevo) {
        if (ColaLlena()) {
            System.out.println("Error: No se puede insertar, la cola está llena");
            return;
        }
        
        if (ColaVacia()) {
            Frente = 0;
            Final = 0;
            Nuevo.setAnt(0);
            Nuevo.setSig(0);
        } else {
            int NuevoFinal = (Final + 1) % Tmax;
            int Anterior = Final;
            
            Nuevo.setAnt(Anterior);
            Nuevo.setSig(Frente);
            
            Arr[Anterior].setSig(NuevoFinal);
            Arr[Frente].setAnt(NuevoFinal);
            
            Final = NuevoFinal;
        }
        
        Arr[Final] = Nuevo;
        Contador++;
        System.out.println("Alumno insertado correctamente");
    }
    
    public void Elimina() {
        if (ColaVacia()) {
            System.out.println("Error: No se puede eliminar, la cola está vacía");
            return;
        }
        
        System.out.println("Eliminando alumno: " + Arr[Frente].getNom());
        
        if (Contador == 1) {
            Frente = -1;
            Final = -1;
        } else {
            int NuevoFrente = Arr[Frente].getSig();
            int UltimoPos = Arr[Frente].getAnt();
            
            Arr[NuevoFrente].setAnt(UltimoPos);
            Arr[UltimoPos].setSig(NuevoFrente);
            
            Frente = NuevoFrente;
        }
        
        Contador--;
    }
    
    public void ListarDerecha() {
        if (ColaVacia()) {
            System.out.println("La cola está vacía");
            return;
        }
        
        System.out.println("\n=== Listado de Derecha (Frente -> Final) ===");
        System.out.println(String.format("%-5s %-15s %-20s %-25s %-15s %-25s %-5s", 
            "Ant", "No. Control", "Nombre", "Domicilio", "Teléfono", "Email", "Sig"));
        System.out.println("=".repeat(120));
        
        int Pos = Frente;
        int Visitados = 0;
        
        do {
            System.out.print(String.format("%-5d ", Arr[Pos].getAnt()));
            System.out.print(Arr[Pos].toString());
            System.out.println(String.format(" %-5d", Arr[Pos].getSig()));
            
            Pos = Arr[Pos].getSig();
            Visitados++;
        } while (Visitados < Contador);
        
        System.out.println("=".repeat(120));
        System.out.println("Total de alumnos: " + Contador);
    }
    
    public void ListarIzquierda() {
        if (ColaVacia()) {
            System.out.println("La cola está vacía");
            return;
        }
        
        System.out.println("\n=== Listado de Izquierda (Final -> Frente) ===");
        System.out.println(String.format("%-5s %-15s %-20s %-25s %-15s %-25s %-5s", 
            "Ant", "No. Control", "Nombre", "Domicilio", "Teléfono", "Email", "Sig"));
        System.out.println("=".repeat(120));
        
        int Pos = Final;
        int Visitados = 0;
        
        do {
            System.out.print(String.format("%-5d ", Arr[Pos].getAnt()));
            System.out.print(Arr[Pos].toString());
            System.out.println(String.format(" %-5d", Arr[Pos].getSig()));
            
            Pos = Arr[Pos].getAnt();
            Visitados++;
        } while (Visitados < Contador);
        
        System.out.println("=".repeat(120));
        System.out.println("Total de alumnos: " + Contador);
    }
    
}
//Eliminamos eliminar final e insertar frente

