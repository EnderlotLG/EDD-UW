package Proyecto10;

import java.util.Scanner;

/**
 *
 * @author fdogs
 */
public class Proyecto10 {
    static Scanner leer = new Scanner(System.in);
    static ColasCircularesE CCE;
    static ColasCircularesD CCD;
    static boolean usarEstatica = true;
    
    public static void main(String[] args) {
        mostrarBienvenida();
        elegirTipoCola();
        
        int op = 0;
        while (op != 6) {
            mostrarMenu();
            op = leerOpcion();
            leer.nextLine(); // Consumir el salto de línea
            
            switch (op) {
                case 1:
                    insertarAlumno();
                    break;
                case 2:
                    eliminarAlumno();
                    break;
                case 3:
                    listarDerecha();
                    break;
                case 4:
                    listarIzquierda();
                    break;
                case 5:
                    mostrarEstadoCola();
                    break;
                case 6:
                    System.out.println("\n¡Gracias por usar el sistema! Hasta pronto.");
                    break;
                default:
                    System.out.println("\nOpción inválida. Por favor intente de nuevo.");
            }
            
            if (op != 6) {
                pausar();
            }
        }
        
        leer.close();
    }
    
    private static void mostrarBienvenida() {
        System.out.println("=".repeat(60));
        System.out.println("    SISTEMA DE GESTIÓN DE COLAS CIRCULARES DE ALUMNOS");
        System.out.println("=".repeat(60));
    }
    
    private static void elegirTipoCola() {
        System.out.println("\n¿Qué tipo de cola desea utilizar?");
        System.out.println("1. Cola Circular Estática (tamaño fijo)");
        System.out.println("2. Cola Circular Dinámica (tamaño variable)");
        System.out.print("Opción: ");
        
        int tipo = leerOpcion();
        leer.nextLine();
        
        if (tipo == 1) {
            System.out.print("Ingrese el tamaño máximo de la cola: ");
            int tamanio = leerOpcion();
            leer.nextLine();
            CCE = new ColasCircularesE(-1, -1, tamanio);
            usarEstatica = true;
            System.out.println("\n✓ Cola estática creada con capacidad de " + tamanio + " elementos");
        } else {
            CCD = new ColasCircularesD();
            usarEstatica = false;
            System.out.println("\n✓ Cola dinámica creada (sin límite de elementos)");
        }
    }
    
    private static void mostrarMenu() {
        System.out.println("\n" + "=".repeat(60));
        System.out.println("                         MENÚ PRINCIPAL");
        System.out.println("=".repeat(60));
        System.out.println("1. Insertar alumno");
        System.out.println("2. Eliminar alumno");
        System.out.println("3. Listar a la derecha (Frente -> Final)");
        System.out.println("4. Listar a la izquierda (Final -> Frente)");
        System.out.println("5. Mostrar estado de la cola");
        System.out.println("6. Salir");
        System.out.println("=".repeat(60));
        System.out.print("Seleccione una opción: ");
    }
    
    private static void insertarAlumno() {
        if (usarEstatica && CCE.ColaLlena()) {
            System.out.println("\n✗ Error: La cola está llena, no se puede insertar más alumnos");
            return;
        }
        
        System.out.println("\n--- Insertar Nuevo Alumno ---");
        
        Alumno Nuevo = new Alumno();
        
        System.out.print("Número de control: ");
        Nuevo.setNC(leer.nextLine().trim());
        
        System.out.print("Nombre completo: ");
        Nuevo.setNom(leer.nextLine().trim());
        
        System.out.print("Domicilio: ");
        Nuevo.setDom(leer.nextLine().trim());
        
        System.out.print("Teléfono: ");
        Nuevo.setTel(leer.nextLine().trim());
        
        System.out.print("Email: ");
        Nuevo.setEmail(leer.nextLine().trim());
        
        if (usarEstatica) {
            CCE.Inserta(Nuevo);
        } else {
            CCD.Inserta(Nuevo);
        }
    }
    
    private static void eliminarAlumno() {
        if ((usarEstatica && CCE.ColaVacia()) || (!usarEstatica && CCD.ColaVacia())) {
            System.out.println("\n✗ Error: La cola está vacía, no hay elementos para eliminar");
            return;
        }
        
        System.out.println("\n--- Eliminar Alumno del Frente ---");
        
        if (usarEstatica) {
            CCE.Elimina();
        } else {
            CCD.Elimina();
        }
    }
    
    private static void listarDerecha() {
        if ((usarEstatica && CCE.ColaVacia()) || (!usarEstatica && CCD.ColaVacia())) {
            System.out.println("\n✗ La cola está vacía, no hay elementos para mostrar");
            return;
        }
        
        if (usarEstatica) {
            CCE.ListarDerecha();
        } else {
            CCD.ListarDerecha();
        }
    }
    
    private static void listarIzquierda() {
        if ((usarEstatica && CCE.ColaVacia()) || (!usarEstatica && CCD.ColaVacia())) {
            System.out.println("\n✗ La cola está vacía, no hay elementos para mostrar");
            return;
        }
        
        if (usarEstatica) {
            CCE.ListarIzquierda();
        } else {
            CCD.ListarIzquierda();
        }
    }
    
    private static void mostrarEstadoCola() {
        System.out.println("\n--- Estado de la Cola ---");
        
        if (usarEstatica) {
            System.out.println("Tipo: Cola Circular Estática");
            System.out.println("Capacidad máxima: " + CCE.getTmax());
            System.out.println("Estado: " + (CCE.ColaVacia() ? "Vacía" : 
                               CCE.ColaLlena() ? "Llena" : "Con elementos"));
            System.out.println("Posición Frente: " + CCE.getFrente());
            System.out.println("Posición Final: " + CCE.getFinal());
        } else {
            System.out.println("Tipo: Cola Circular Dinámica");
            System.out.println("Elementos actuales: " + CCD.getTamanio());
            System.out.println("Estado: " + (CCD.ColaVacia() ? "Vacía" : "Con elementos"));
            System.out.println("Posición Frente: " + CCD.getFrente());
            System.out.println("Posición Final: " + CCD.getFinal());
        }
    }
    
    private static int leerOpcion() {
        while (!leer.hasNextInt()) {
            System.out.print("Por favor ingrese un número válido: ");
            leer.next();
        }
        return leer.nextInt();
    }
    
    private static void pausar() {
        System.out.print("\nPresione ENTER para continuar...");
        leer.nextLine();
    }

}