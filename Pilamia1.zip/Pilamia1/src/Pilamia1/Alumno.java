
package Pilamia1;

/**
 *
 * @author fdogs
 */
public class Alumno {
    private String Nc;
    private String Nom;
    private String Dom;
    private String Tel;
    private String Email;

    public String getNc() {
        return Nc;
    }

    public void setNc(String Nc) {
        this.Nc = Nc;
    }

    public String getNom() {
        return Nom;
    }

    public void setNom(String Nom) {
        this.Nom = Nom;
    }

    public String getDom() {
        return Dom;
    }

    public void setDom(String Dom) {
        this.Dom = Dom;
    }

    public String getTel() {
        return Tel;
    }

    public void setTel(String Tel) {
        this.Tel = Tel;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public Alumno(String Nc, String Nom, String Dom, String Tel, String Email) {
        this.Nc = Nc;
        this.Nom = Nom;
        this.Dom = Dom;
        this.Tel = Tel;
        this.Email = Email;
    }

    public Alumno(){
    
    
   }
}
