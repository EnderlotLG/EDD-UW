
package Pilamia1;
import java.util.Scanner;
import java.util.Stack;
/**
 * @author fdogs
 * Implementación de una agenda utilizando un tipo de dato abstracto Alumno
 * utilizando PILAS
 */
public class Pilamia1 {
public static Scanner s = new Scanner(System.in);
    public static Stack<Alumno> Agenda = new Stack<>();

    public static void Inicializar() {
        //inicializa la pila
        Agenda = new Stack<>();
    }

    public static Alumno Buscar(String EB) {
        if (EB.equals("+")) {
            System.out.println("Buscar alumnos");
            System.out.println("Numero de control a buscar: ");
            EB = s.next();
        }

        Stack<Alumno> temp = new Stack<>();
        Alumno encontrado = null;
        boolean esta = false;

        while (!Agenda.isEmpty() && !esta) {
            Alumno actual = Agenda.pop();
            temp.push(actual);
            if (actual.getNc().equals(EB)) {
                encontrado = actual;
                esta = true;
            }
        }

        while (!temp.isEmpty()) {
            Agenda.push(temp.pop());
        }

        return encontrado;
    }

    public static void Agregar() {
        System.out.println("Agrega alumnos");
        Alumno Nuevo = new Alumno("", "", "", "", "");
        System.out.println("Escribe el numero de control: ");
        Nuevo.setNc(s.next());
        System.out.println("Escibre el nombre: ");
        Nuevo.setNom(s.next());
        System.out.println("Escribe el domicilio: ");
        Nuevo.setDom(s.next());
        System.out.println("Escirbe el numero de telefono: ");
        Nuevo.setTel(s.next());
        System.out.println("Escribe tu Email: ");
        Nuevo.setEmail(s.next());

        Agenda.push(Nuevo);
    }


    public static void Modificar() {
        System.out.println("Modificar alumnos");
        System.out.println("Escriba el numero de control");
        Alumno b = Buscar(s.next());
        if (b == null) {
            System.out.println("Numero de control no existe");
        } else{
            int op = 0;
            while (op !=5){
            System.out.println("Selecionar campo a modificar");
            System.out.println("1. Nombre 2. domicilio 3. Telefono 4. Email 5. Salir");
            op = s.nextInt();
            switch (op){
                case 1:
                        System.out.println("Nombre Correcto");
                        b.setNom(s.next());
                        break;

                    case 2:
                        System.out.println("Domicilio Correcto");
                        b.setDom(s.next());
                        break;

                    case 3:
                        System.out.println("Telefono Correcto");
                        b.setTel(s.next());
                        break;

                    case 4:
                        System.out.println("Email correcto");
                        b.setEmail(s.next());
                        break;
                    
            }
        }
        
       }
    }

    public static void Consultar() {
        System.out.println("Consultar alumnos");
        if (Agenda.isEmpty()) {
            System.out.println("la Pila esta vacia");
        } else {
            Stack<Alumno> temp = new Stack<>();
            
            while (!Agenda.isEmpty()) {
                Alumno actual = Agenda.pop();
                System.out.print(actual.getNc() + "\t");
                System.out.print(actual.getNom() + "\t");
                System.out.print(actual.getDom() + "\t");
                System.out.print(actual.getTel() + "\t");
                System.out.println(actual.getEmail() + "\t");
                temp.push(actual);
            }
            
            while (!temp.isEmpty()) {
                Agenda.push(temp.pop());
            }
        }

    }
    
    public static void Eliminar() {
        System.out.println("Eliminar alumnos");
        if (Agenda.isEmpty()) {
            System.out.println("Pila Vacia");
        } else {
            System.out.println("Escriba el numero de control ");
            String EB = s.next();
            
            Stack<Alumno> temp = new Stack<>();
            boolean encontrado = false;

            while (!Agenda.isEmpty() && !encontrado) {
                Alumno actual = Agenda.pop();
                if (actual.getNc().equals(EB)) {
                    encontrado = true;
                } else {
                    temp.push(actual);
                }
            }

            while (!temp.isEmpty()) {
                Agenda.push(temp.pop());
            }

            if (!encontrado) {
                System.out.println("El nc no existe");
            }
        }
    }

    public static void main(String[] args) {
        int op = 0;
        Inicializar();
        while (op != 6) {
            System.out.println("1. Agrega 2.Elimina 3.Modifica 4.Busca 5.Consulta 6.Salir");
            op = s.nextInt();
            switch (op) {
                case 1:
                    Agregar();
                    break;
                case 2:
                   Eliminar();
                    break;
                case 3:
                    Modificar();
                    break;
                case 4:
                    if (Buscar("+") == null) {
                        System.out.println("El numero de control no existe");
                    } else {
                        System.out.println("El numero de control si existe");
                    }
                    break;
                case 5:
                    Consultar();
                    break;
            }
        }
    }
}
   
    