package proyecto.pkg6;

/**
 * Clase Alumno - utilizada en la pila
 */
public class Alumno {

    private String nc;
    private String nom;
    private String dom;
    private String tel;
    private String email;
    private Alumno ptr;

    public Alumno() {
    }

    public Alumno(String nc, String nom, String dom, String tel, String email, Alumno ptr) {
        this.nc = nc;
        this.nom = nom;
        this.dom = dom;
        this.tel = tel;
        this.email = email;
        this.ptr = ptr;
    }

    public String getNc() {
        return nc;
    }

    public void setNc(String nc) {
        this.nc = nc;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getDom() {
        return dom;
    }

    public void setDom(String dom) {
        this.dom = dom;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Alumno getPtr() {
        return ptr;
    }

    public void setPtr(Alumno ptr) {
        this.ptr = ptr;
    }

    @Override
    public String toString() {
        return String.format("%-15s %-20s %-25s %-15s %-25s",
                nc != null ? nc : "",
                nom != null ? nom : "",
                dom != null ? dom : "",
                tel != null ? tel : "",
                email != null ? email : "");
    }
}
