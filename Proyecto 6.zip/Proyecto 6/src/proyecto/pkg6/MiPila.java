package proyecto.pkg6;

/**
 * Implementacion de pila usando lista enlazada
 *
 * @author fdogs
 */
public class MiPila {

    private Alumno cima;
    private final int max;
    private int cuenta;

    public MiPila(Alumno cima, int max, int cuenta) {
        this.cima = cima;
        this.max = max;
        this.cuenta = cuenta;
    }

    public boolean PilaVacia() {
        return cima == null;
    }

    public boolean PilaLlena() {
        return cuenta == max;
    }

    public void Meter(Alumno nuevo) {
        if (PilaLlena()) {
            throw new RuntimeException("Pila llena");
        }
        nuevo.setPtr(cima);
        cima = nuevo;
        cuenta++;
    }

    public Alumno Sacar() {
        if (PilaVacia()) {
            throw new RuntimeException("Pila vacia");
        }
        Alumno temp = cima;
        cima = cima.getPtr();
        cuenta--;
        return temp;
    }

    public Alumno Mostrar() {
        if (PilaVacia()) {
            throw new RuntimeException("Pila vacia");
        }
        return cima;
    }

    public void ListarPila() {
        Alumno actual = cima;
        while (actual != null) {
            System.out.printf("%-15s %-20s %-25s %-15s %-25s%n",
                    actual.getNc(), actual.getNom(), actual.getDom(),
                    actual.getTel(), actual.getEmail());
            actual = actual.getPtr();
        }
    }

    public Alumno getCima() {
        return cima;
    }

    public int getMax() {
        return max;
    }

    public int getCuenta() {
        return cuenta;
    }
}
