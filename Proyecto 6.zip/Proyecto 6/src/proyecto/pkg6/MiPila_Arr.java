package proyecto.pkg6;

/**
 * Implementacion de pila usando arreglos
 *
 * @author fdogs
 */
public class MiPila_Arr {
    private int cima;
    private final int max;
    private final Alumno[] arr;

    public MiPila_Arr(int cima, int max) {
        this.cima = cima;
        this.max = max;
        this.arr = new Alumno[max];
    }

    public boolean PilaVacia() {
        return cima == -1;
    }

    public boolean PilaLlena() {
        return cima == max - 1;
    }

    public void Meter(Alumno nuevo) {
        if (PilaLlena()) {
            throw new RuntimeException("Pila llena");
        }
        arr[++cima] = nuevo;
    }

    public Alumno Sacar() {
        if (PilaVacia()) {
            throw new RuntimeException("Pila vacia");
        }
        return arr[cima--];
    }

    public Alumno Mostrar() {
        if (PilaVacia()) {
            throw new RuntimeException("Pila vacia");
        }
        return arr[cima];
    }

    public void ListarPila() {
        for (int i = cima; i >= 0; i--) {
            Alumno alumno = arr[i];
            System.out.printf("%-15s %-20s %-25s %-15s %-25s%n",
                    alumno.getNc(), alumno.getNom(), alumno.getDom(),
                    alumno.getTel(), alumno.getEmail());
        }
    }

    public int getCima() {
        return cima;
    }

    public int getMax() {
        return max;
    }
}