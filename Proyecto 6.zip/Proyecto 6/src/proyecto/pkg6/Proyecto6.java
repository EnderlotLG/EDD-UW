package proyecto.pkg6;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * Implementacion de una pila
 *
 * @author fdogs
 */
public class Proyecto6 {

    private static final Scanner scanner = new Scanner(System.in);
    private static final MiPila pila = new MiPila(null, 10, 0);
    private static final MiPila_Arr pilaArr = new MiPila_Arr(-1, 10);

    public static void main(String[] args) {
        try {
            mostrarMenu();
        } finally {
            scanner.close();
        }
    }

    private static void mostrarMenu() {
        int opcion = 0;
        while (opcion != 5) {
            System.out.println("\n=== MENU PRINCIPAL ===");
            System.out.println("1. Meter\n2. Sacar\n3. Mostrar Cima\n4. Listar Pila\n5. Salir");
            System.out.print("Seleccione una opcion: ");
            
            try {
                opcion = scanner.nextInt();
                scanner.nextLine(); // Limpiar buffer
                
                switch (opcion) {
                    case 1 -> agregarAlumno();
                    case 2 -> sacarAlumno();
                    case 3 -> mostrarCima();
                    case 4 -> listarPila();
                    case 5 -> System.out.println("Saliendo del programa...");
                    default -> System.out.println("Opcion invalida. Intente de nuevo.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Error: Ingrese un numero valido.");
                scanner.nextLine(); // Limpiar buffer
            }
        }
    }

    private static void agregarAlumno() {
        if (pila.PilaLlena()) {
            System.out.println("La pila esta llena");
            return;
        }
        
        Alumno nuevo = crearAlumno();
        if (nuevo != null) {
            pila.Meter(nuevo);
            pilaArr.Meter(nuevo);
            System.out.println("Alumno agregado exitosamente.");
        }
    }

    private static Alumno crearAlumno() {
        try {
            System.out.print("Numero de Control: ");
            String nc = scanner.nextLine().trim();
            System.out.print("Nombre: ");
            String nom = scanner.nextLine().trim();
            System.out.print("Domicilio: ");
            String dom = scanner.nextLine().trim();
            System.out.print("Telefono: ");
            String tel = scanner.nextLine().trim();
            System.out.print("Email: ");
            String email = scanner.nextLine().trim();
            
            return new Alumno(nc, nom, dom, tel, email, null);
        } catch (Exception e) {
            System.out.println("Error al crear alumno: " + e.getMessage());
            return null;
        }
    }

    private static void sacarAlumno() {
        if (pila.PilaVacia()) {
            System.out.println("Pila vacia");
            return;
        }
        
        System.out.println("\nSacar - Memoria Estatica (Array):");
        mostrarAlumno(pilaArr.Sacar());
        
        System.out.println("\nSacar - Memoria Dinamica (Lista):");
        mostrarAlumno(pila.Sacar());
    }

    private static void mostrarCima() {
        if (pila.PilaVacia()) {
            System.out.println("Pila vacia");
            return;
        }
        
        System.out.println("\nCima - Memoria Dinamica (Lista):");
        mostrarAlumno(pila.Mostrar());
        
        System.out.println("\nCima - Memoria Estatica (Array):");
        mostrarAlumno(pilaArr.Mostrar());
    }

    private static void listarPila() {
        if (pila.PilaVacia()) {
            System.out.println("Pila vacia");
            return;
        }
        
        System.out.println("\nElementos - Memoria Dinamica (Lista):");
        pila.ListarPila();
        
        System.out.println("\nElementos - Memoria Estatica (Array):");
        pilaArr.ListarPila();
    }

    private static void mostrarAlumno(Alumno alumno) {
        if (alumno != null) {
            System.out.printf("%-15s %-20s %-25s %-15s %-25s%n",
                    alumno.getNc(), alumno.getNom(), alumno.getDom(),
                    alumno.getTel(), alumno.getEmail());
        }
    }
}