
package proyecto4;


/**
 * Clase ListaAlumnos - Lista enlazada con método de ordenamiento burbuja
 */
class ListaAlumnos {
    private AlumnoNodo Inicio;
    
    public ListaAlumnos() {
        this.Inicio = null;
    }
    
    public boolean ListaVacia() {
        return Inicio == null;
    }
    
    /**
     * Inserta un alumno al final de la lista
     */
    public void Insertar(AlumnoNodo nuevo) {
        if (ListaVacia()) {
            Inicio = nuevo;
        } else {
            AlumnoNodo p = Inicio;
            while (p.getSig() != null) {
                p = p.getSig();
            }
            p.setSig(nuevo);
        }
    }
    
    /**
     * Lista todos los alumnos
     */
    public void Listar() {
        if (ListaVacia()) {
            System.out.println("Lista vacía");
            return;
        }
        
        System.out.println("\n=== LISTA DE ALUMNOS ===");
        System.out.println("NC\t\tNombre\t\tDomicilio\tTeléfono\tEmail");
        System.out.println("-------------------------------------------------------------------------");
        
        AlumnoNodo p = Inicio;
        while (p != null) {
            System.out.print(p.getNc() + "\t\t");
            System.out.print(p.getNom() + "\t\t");
            System.out.print(p.getDom() + "\t\t");
            System.out.print(p.getTel() + "\t\t");
            System.out.println(p.getEmail());
            p = p.getSig();
        }
    }
    
    /**
     * Cuenta el número de elementos en la lista
     */
    private int ContarElementos() {
        int cont = 0;
        AlumnoNodo p = Inicio;
        while (p != null) {
            cont++;
            p = p.getSig();
        }
        return cont;
    }
    
    /**
     * Método de la Burbuja para ordenar por Número de Control
     */
    public void OrdenarBurbujaPorNc() {
        if (ListaVacia() || Inicio.getSig() == null) {
            return; // Lista vacía o con un solo elemento
        }
        
        int n = ContarElementos();
        boolean intercambio;
        
        for (int i = 0; i < n - 1; i++) {
            intercambio = false;
            AlumnoNodo actual = Inicio;
            AlumnoNodo anterior = null;
            AlumnoNodo siguiente = Inicio.getSig();
            
            for (int j = 0; j < n - 1 - i; j++) {
                // Comparar números de control
                if (actual.getNc().compareTo(siguiente.getNc()) > 0) {
                    intercambio = true;
                    
                    // Intercambiar nodos
                    if (anterior != null) {
                        anterior.setSig(siguiente);
                    } else {
                        Inicio = siguiente;
                    }
                    
                    actual.setSig(siguiente.getSig());
                    siguiente.setSig(actual);
                    
                    // Actualizar punteros
                    anterior = siguiente;
                    siguiente = actual.getSig();
                } else {
                    // Avanzar punteros
                    anterior = actual;
                    actual = siguiente;
                    siguiente = siguiente.getSig();
                }
                
                if (siguiente == null) {
                    break;
                }
            }
            
            if (!intercambio) {
                break; // Si no hubo intercambios, la lista ya está ordenada
            }
        }
    }
    
    /**
     * Método de la Burbuja para ordenar por Nombre
     */
    public void OrdenarBurbujaPorNombre() {
        if (ListaVacia() || Inicio.getSig() == null) {
            return; // Lista vacía o con un solo elemento
        }
        
        int n = ContarElementos();
        boolean intercambio;
        
        for (int i = 0; i < n - 1; i++) {
            intercambio = false;
            AlumnoNodo actual = Inicio;
            AlumnoNodo anterior = null;
            AlumnoNodo siguiente = Inicio.getSig();
            
            for (int j = 0; j < n - 1 - i; j++) {
                // Comparar nombres
                if (actual.getNom().compareTo(siguiente.getNom()) > 0) {
                    intercambio = true;
                    
                    // Intercambiar nodos
                    if (anterior != null) {
                        anterior.setSig(siguiente);
                    } else {
                        Inicio = siguiente;
                    }
                    
                    actual.setSig(siguiente.getSig());
                    siguiente.setSig(actual);
                    
                    // Actualizar punteros
                    anterior = siguiente;
                    siguiente = actual.getSig();
                } else {
                    // Avanzar punteros
                    anterior = actual;
                    actual = siguiente;
                    siguiente = siguiente.getSig();
                }
                
                if (siguiente == null) {
                    break;
                }
            }
            
            if (!intercambio) {
                break; // Si no hubo intercambios, la lista ya está ordenada
            }
        }
    }
    
    /**
     * Elimina un alumno por su número de control
     */
    public void Eliminar(String nc) {
        if (ListaVacia()) {
            System.out.println("Lista vacía");
            return;
        }
        
        // Si el primer nodo es el que se busca
        if (Inicio.getNc().equals(nc)) {
            Inicio = Inicio.getSig();
            System.out.println("Alumno eliminado exitosamente.");
            return;
        }
        
        // Buscar en el resto de la lista
        AlumnoNodo p = Inicio;
        while (p.getSig() != null) {
            if (p.getSig().getNc().equals(nc)) {
                p.setSig(p.getSig().getSig());
                System.out.println("Alumno eliminado exitosamente.");
                return;
            }
            p = p.getSig();
        }
        
        System.out.println("Alumno no encontrado.");
    }
}

