
package proyecto4;

import java.util.Scanner;

/**
 *  Método de la Burbuja con Punteros
 * @author fdogs
 */
public class Proyecto4 {
    static Scanner s = new Scanner(System.in);
    static ListaAlumnos lista = new ListaAlumnos();
    
    public static void main(String[] args) {
        int op = 0;
        while (op != 6) {
            System.out.println("\n=== MENU ORDENAMIENTO BURBUJA ===");
            System.out.println("1. Agregar Alumno");
            System.out.println("2. Listar Alumnos");
            System.out.println("3. Ordenar por Numero de Control (Burbuja)");
            System.out.println("4. Ordenar por Nombre (Burbuja)");
            System.out.println("5. Eliminar Alumno");
            System.out.println("6. Salir");
            System.out.print("Opcion: ");
            op = s.nextInt();
            
            switch (op) {
                case 1: // AGREGAR ALUMNO
                    System.out.print("Numero de Control: ");
                    String nc = s.next();
                    System.out.print("Nombre: ");
                    String nom = s.next();
                    System.out.print("Domicilio: ");
                    String dom = s.next();
                    System.out.print("Telefono: ");
                    String tel = s.next();
                    System.out.print("Email: ");
                    String email = s.next();
                    
                    AlumnoNodo nuevo = new AlumnoNodo(nc, nom, dom, tel, email);
                    lista.Insertar(nuevo);
                    System.out.println("Alumno agregado exitosamente.");
                    break;
                    
                case 2: // LISTAR ALUMNOS
                    lista.Listar();
                    break;
                    
                case 3: // ORDENAR POR NUMERO DE CONTROL
                    lista.OrdenarBurbujaPorNc();
                    System.out.println("Lista ordenada por Numero de Control.");
                    lista.Listar();
                    break;
                    
                case 4: // ORDENAR POR NOMBRE
                    lista.OrdenarBurbujaPorNombre();
                    System.out.println("Lista ordenada por Nombre.");
                    lista.Listar();
                    break;
                    
                case 5: // ELIMINAR ALUMNO
                    System.out.print("Numero de Control del alumno a eliminar: ");
                    String ncElim = s.next();
                    lista.Eliminar(ncElim);
                    break;
                    
                case 6:
                    System.out.println("Saliendo del programa...");
                    break;
                    
                default:
                    System.out.println("Opción inválida. Intente de nuevo.");
                    break;
            }
        }
        s.close();
    }
}