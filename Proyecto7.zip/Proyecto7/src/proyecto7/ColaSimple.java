package proyecto7;
/**
 *
 * @author fdogs implementacion de cola simple memoria dinamica
 */
public class ColaSimple {
    private Alumno Frente;
    private Alumno Final;
    private int TMax;
    private int Cuenta;
    
    public Alumno getFrente() {
        return Frente;
    }
    
    public void setFrente(Alumno Frente) {
        this.Frente = Frente;
    }
    
    public Alumno getFinal() {
        return Final;
    }
    
    public void setFinal(Alumno Final) {
        this.Final = Final;
    }
    
    public int getTMax() {
        return TMax;
    }
    
    public void setTMax(int TMax) {
        this.TMax = TMax;
    }
    
    public int getCuenta() {
        return Cuenta;
    }
    
    public void setCuenta(int Cuenta) {
        this.Cuenta = Cuenta;
    }
    
    public ColaSimple(Alumno Frente, Alumno Final, int TMax, int Cuenta) {
        this.Frente = Frente;
        this.Final = Final;
        this.TMax = TMax;
        this.Cuenta = Cuenta;
    }
    
    public boolean ColaVacia() {
        return (this.Frente == this.Final && this.Frente == null);
    }
    
    public boolean ColaLlena() {
        return this.Cuenta == this.TMax;
    }
    
    public void Insertar(Alumno Nuevo) {
        if (ColaVacia()) {
            this.Frente = Nuevo;
        } else {
            this.Final.setPtr(Nuevo);
        }
        this.Final = Nuevo;
        this.Cuenta++;
    }
    
    public void Eliminar() {
        if(this.Frente == this.Final){
            this.Frente = null;
            this.Final = null;
        } else {
            this.Frente = this.Frente.getPtr();
        }
        this.Cuenta--;
    }
    
    public void MostrarFrente() {
        System.out.print(this.Frente.getNc() + "\t");
        System.out.print(this.Frente.getNom() + "\t");
        System.out.print(this.Frente.getDom() + "\t");
        System.out.print(this.Frente.getTel() + "\t");
        System.out.println(this.Frente.getEmail());
    }
    
    public void ListarCola() {
        Alumno Pos = null;
        do {
            if (Pos == null) {
                Pos = this.Frente;
            } else {
                Pos = Pos.getPtr();
            }
            // CORRECCIÓN: Usar Pos en lugar de this.Frente
            System.out.print(Pos.getNc() + "\t");
            System.out.print(Pos.getNom() + "\t");
            System.out.print(Pos.getDom() + "\t");
            System.out.print(Pos.getTel() + "\t");
            System.out.println(Pos.getEmail() + "\t");
        } while (Pos != this.Final);
    }
}