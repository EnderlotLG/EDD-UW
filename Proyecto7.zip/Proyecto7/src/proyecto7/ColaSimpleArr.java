package proyecto7;

/**
 * Implementación de cola simple con memoria estática (arreglos)
 * @author fdogs
 */
public class ColaSimpleArr {
    private Alumno[] Cola;
    private int Frente;
    private int Final;
    private int TMax;
    
    public ColaSimpleArr(int TMax) {
        this.TMax = TMax;
        this.Cola = new Alumno[TMax];
        this.Frente = -1;
        this.Final = -1;
    }
    
    public boolean ColaVacia() {
        return (this.Frente == -1 && this.Final == -1);
    }
    

    public boolean ColaLlena() {
        return (this.Final == this.TMax - 1);
    }
    
    public void Insertar(Alumno Nuevo) {
        if (ColaVacia()) {
            this.Frente = 0;
            this.Final = 0;
            this.Cola[this.Final] = Nuevo;
        } else {
            this.Final++;
            this.Cola[this.Final] = Nuevo;
        }
    }
    
    public void Eliminar() {
        if (this.Frente == this.Final) {
            this.Frente = -1;
            this.Final = -1;
        } else {
            this.Frente++;
        }
    }
    
    public void MostrarFrente() {
        System.out.print(this.Cola[this.Frente].getNc() + "\t");
        System.out.print(this.Cola[this.Frente].getNom() + "\t");
        System.out.print(this.Cola[this.Frente].getDom() + "\t");
        System.out.print(this.Cola[this.Frente].getTel() + "\t");
        System.out.println(this.Cola[this.Frente].getEmail());
    }
    public void ListarCola() {
        for (int i = this.Frente; i <= this.Final; i++) {
            System.out.print(this.Cola[i].getNc() + "\t");
            System.out.print(this.Cola[i].getNom() + "\t");
            System.out.print(this.Cola[i].getDom() + "\t");
            System.out.print(this.Cola[i].getTel() + "\t");
            System.out.println(this.Cola[i].getEmail() + "\t");
        }
    }
    
    public int getFrente() {
        return Frente;
    }
    
    public void setFrente(int Frente) {
        this.Frente = Frente;
    }
    
    public int getFinal() {
        return Final;
    }
    
    public void setFinal(int Final) {
        this.Final = Final;
    }
    
    public int getTMax() {
        return TMax;
    }
    
    public void setTMax(int TMax) {
        this.TMax = TMax;
    }
    
    public Alumno[] getCola() {
        return Cola;
    }
    
    public void setCola(Alumno[] Cola) {
        this.Cola = Cola;
    }
    
    public int getCuenta() {
        if (ColaVacia()) {
            return 0;
        }
        return (this.Final - this.Frente + 1);
    }
}