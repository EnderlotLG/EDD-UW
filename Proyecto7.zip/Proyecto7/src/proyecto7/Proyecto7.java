package proyecto7;
import java.util.Scanner;

/**
 * Implementación de funcionamiento de una cola simple
 * Comparación entre memoria dinámica (punteros) y estática (arreglos)
 * @author fdogs
 */
public class Proyecto7 {
    static Scanner s = new Scanner(System.in);
    static ColaSimple CS = new ColaSimple(null, null, 3, 0);      // Cola con memoria dinámica
    static ColaSimpleArr CS_Arr = new ColaSimpleArr(3);            // Cola con arreglos
    
    public static void main(String[] args) {
        int op = 0;
        while (op != 5) {
            System.out.println("\n=== MENU COLA SIMPLE ===");
            System.out.println("1. Meter");
            System.out.println("2. Sacar");
            System.out.println("3. Mostrar Frente");
            System.out.println("4. Listar Cola");
            System.out.println("5. Salir");
            System.out.print("Opcion: ");
            op = s.nextInt();
            
            switch (op) {
                case 1:
                    // Verificar si ambas colas están llenas
                    if (CS.ColaLlena() && CS_Arr.ColaLlena()) {
                        System.out.println("Ambas colas están llenas");
                    } else {
                        Alumno Nuevo = new Alumno();
                        System.out.print("Numero de Control: ");
                        Nuevo.setNc(s.next());
                        System.out.print("Nombre: ");
                        Nuevo.setNom(s.next());
                        System.out.print("Domicilio: ");
                        Nuevo.setDom(s.next());
                        System.out.print("Telefono: ");
                        Nuevo.setTel(s.next());
                        System.out.print("Email: ");
                        Nuevo.setEmail(s.next());
                        Nuevo.setPtr(null);
                        
                        // Insertar en cola dinamica
                        if (!CS.ColaLlena()) {
                            CS.Insertar(Nuevo);
                        }
                        
                        // Insertar en cola con arreglos
                        if (!CS_Arr.ColaLlena()) {
                            CS_Arr.Insertar(Nuevo);
                        }
                        
                        System.out.println("Alumno agregado exitosamente.");
                    }
                    break;
                    
                case 2:
                    if (CS.ColaVacia() && CS_Arr.ColaVacia()) {
                        System.out.println("Ambas estan vacias");
                    } else {
                        if (!CS.ColaVacia()) {
                            System.out.println("\n--- Eliminando de Cola D ---");
                            CS.MostrarFrente();
                            CS.Eliminar();
                        }
                        
                        if (!CS_Arr.ColaVacia()) {
                            System.out.println("\n--- Eliminando de Cola con Arr ---");
                            CS_Arr.MostrarFrente();
                            CS_Arr.Eliminar();
                        }
                        System.out.println("Elemento(s) eliminado(s)");
                    }
                    break;
                    
                case 3:
                    if (CS.ColaVacia() && CS_Arr.ColaVacia()) {
                        System.out.println("Ambas colas estan vacias");
                    } else {
                        if (!CS.ColaVacia()) {
                            System.out.println("\n--- Frente Cola D ---");
                            CS.MostrarFrente();
                        }
                        
                        if (!CS_Arr.ColaVacia()) {
                            System.out.println("\n--- Frente Cola con Arr ---");
                            CS_Arr.MostrarFrente();
                        }
                    }
                    break;
                    
                case 4:
                    if (CS.ColaVacia() && CS_Arr.ColaVacia()) {
                        System.out.println("Ambas colas estan vacias");
                    } else {
                        if (!CS.ColaVacia()) {
                            System.out.println("\n=== Elementos en Cola Memoria D (Punteros) ===");
                            CS.ListarCola();
                        }
                        
                        if (!CS_Arr.ColaVacia()) {
                            System.out.println("\n=== Elementos en Cola Memoria E (Arreglos) ===");
                            CS_Arr.ListarCola();
                        }
                        System.out.println();
                    }
                    break;
                    
                case 5:
                    System.out.println("Saliendo del programa...");
                    break;
                    
                default:
                    System.out.println("Opción inválida. Intente de nuevo.");
                    break;
            }
        }
        s.close();
    }
}