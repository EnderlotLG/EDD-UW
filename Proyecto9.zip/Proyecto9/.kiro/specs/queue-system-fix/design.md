# Design Document

## Overview

Este diseño corrige los problemas identificados en el sistema de colas (ColaSimpleArr y ColaDobleE) para eliminar ciclos infinitos y garantizar el comportamiento correcto de las estructuras de datos. Se mantiene la lógica original del código pero se corrigen las condiciones y operaciones defectuosas.

## Architecture

El sistema mantiene su arquitectura original con tres componentes principales:

1. **Alumno**: Clase de datos que representa un estudiante
2. **ColaSimpleArr**: Cola simple FIFO con arreglo estático
3. **ColaDobleE**: Cola doble (deque) con arreglo estático y enlaces bidireccionales
4. **Proyecto9**: Clase principal con menú interactivo

### Principios de Diseño

- **Inmutabilidad de la lógica original**: Se respeta la estructura y enfoque del código fuente
- **Corrección mínima**: Solo se corrigen los bugs identificados sin reescribir el código
- **Validación exhaustiva**: Se agregan tests para verificar ausencia de ciclos

## Components and Interfaces

### ColaSimpleArr (Correcciones)

**Problema identificado**: La condición `ColaVacia()` retorna `Frente == Final`, lo cual es incorrecto porque cuando Final avanza, esta condición se vuelve falsa incluso con elementos en la cola.

**Corrección**:
```java
public boolean ColaVacia() {
    return Frente == -1 && Final == -1;
}
```

**Problema identificado**: La lógica de inserción del primer elemento no incrementa Final correctamente.

**Corrección en Insertar()**:
```java
if (Frente == -1 && Final == -1) {  // Cola vacía
    Frente = 0;
    Final = 0;
    Arr[Final] = Nuevo;
    Final++;  // Final apunta a la siguiente posición libre
}
```

### ColaDobleE (Correcciones)

**Problema identificado**: La condición `ColaLlena()` usa `Final - Frente >= Tmax`, lo cual falla cuando Frente avanza (no considera el número real de elementos).

**Corrección**:
```java
public boolean ColaLlena() {
    if (Frente == -1 && Final == -1) return false;
    return (Final - Frente + 1) >= Tmax;
}
```

**Problema identificado**: En `InsertaFrente()`, cuando se mueven elementos, los punteros Ant/Sig pueden quedar inconsistentes.

**Corrección en InsertaFrente()**:
- Asegurar que después de mover elementos, todos los punteros apunten correctamente
- El último elemento debe tener Sig = -1
- El primer elemento debe tener Ant = -1

### Validación de No-Ciclos

Para evitar ciclos en los recorridos, se implementan las siguientes validaciones:

1. **Límite de iteraciones**: Los bucles de listado usan índices numéricos (Frente a Final) en lugar de seguir punteros
2. **Verificación de rangos**: Antes de acceder a Arr[i], verificar que i esté en rango válido
3. **Detección de punteros circulares**: En tests, verificar que siguiendo Sig nunca regresemos al mismo nodo

## Data Models

### Alumno
```java
class Alumno {
    String Nc;      // Número de control
    String Nom;     // Nombre
    String Dom;     // Domicilio
    String Tel;     // Teléfono
    String Email;   // Email
    int Ant;        // Puntero al anterior (-1 si es el primero)
    int Sig;        // Puntero al siguiente (-1 si es el último)
}
```

### ColaSimpleArr
```java
class ColaSimpleArr {
    Alumno[] Arr;   // Arreglo de tamaño 10
    int Frente;     // Índice del primer elemento (-1 si vacía)
    int Final;      // Índice de la siguiente posición libre (-1 si vacía)
    int Tmax;       // Capacidad máxima
}
```

**Invariantes**:
- Si la cola está vacía: Frente == -1 && Final == -1
- Si la cola tiene elementos: 0 <= Frente < Final <= Tmax
- Número de elementos = Final - Frente (cuando no está vacía)

### ColaDobleE
```java
class ColaDobleE {
    Alumno[] Arr;   // Arreglo de tamaño 10
    int Frente;     // Índice del primer elemento (-1 si vacía)
    int Final;      // Índice del último elemento (-1 si vacía)
    int Tmax;       // Capacidad máxima
}
```

**Invariantes**:
- Si la cola está vacía: Frente == -1 && Final == -1
- Si la cola tiene elementos: 0 <= Frente <= Final < 10
- Número de elementos = Final - Frente + 1 (cuando no está vacía)
- Arr[Frente].Ant == -1
- Arr[Final].Sig == -1
- Para todo i en [Frente, Final): Arr[i].Sig == i+1
- Para todo i en (Frente, Final]: Arr[i].Ant == i-1


## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system-essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Cola vacía es detectada correctamente

*For any* cola (simple o doble), cuando Frente == -1 y Final == -1, entonces ColaVacia() debe retornar true.

**Validates: Requirements 1.1, 2.1**

### Property 2: Inserciones subsecuentes incrementan Final

*For any* ColaSimpleArr con al menos un elemento, cuando se inserta un nuevo elemento, entonces Final debe incrementarse en 1 y Frente debe permanecer sin cambios.

**Validates: Requirements 1.3**

### Property 3: Eliminaciones incrementan Frente

*For any* ColaSimpleArr con más de un elemento, cuando se elimina un elemento, entonces Frente debe incrementarse en 1 y Final debe permanecer sin cambios.

**Validates: Requirements 1.4**

### Property 4: Punteros consistentes después de insertar por el frente

*For any* ColaDobleE no vacía, después de insertar un elemento por el frente, todos los elementos deben tener punteros Ant/Sig consistentes: Arr[i].Sig debe ser i+1 (o -1 si es el último) y Arr[i].Ant debe ser i-1 (o -1 si es el primero).

**Validates: Requirements 2.2**

### Property 5: Punteros consistentes después de insertar por el final

*For any* ColaDobleE, después de insertar un elemento por el final, el elemento anterior debe tener Sig apuntando al nuevo elemento, y el nuevo elemento debe tener Ant apuntando al anterior y Sig = -1.

**Validates: Requirements 2.3**

### Property 6: Eliminación por el frente actualiza punteros

*For any* ColaDobleE con más de un elemento, después de eliminar por el frente, el nuevo primer elemento (Arr[Frente]) debe tener Ant = -1.

**Validates: Requirements 2.4**

### Property 7: Eliminación por el final actualiza punteros

*For any* ColaDobleE con más de un elemento, después de eliminar por el final, el nuevo último elemento (Arr[Final]) debe tener Sig = -1.

**Validates: Requirements 2.5**

### Property 8: Listado de frente a final termina sin ciclos

*For any* cola no vacía, el recorrido de Frente a Final debe visitar exactamente (Final - Frente + 1) elementos para ColaDobleE o (Final - Frente) elementos para ColaSimpleArr, sin exceder los límites del arreglo.

**Validates: Requirements 3.1**

### Property 9: Listado de final a frente termina sin ciclos

*For any* ColaDobleE no vacía, el recorrido de Final a Frente debe visitar exactamente (Final - Frente + 1) elementos sin exceder los límites del arreglo.

**Validates: Requirements 3.2**

### Property 10: Recorrido por punteros no tiene ciclos

*For any* ColaDobleE no vacía, siguiendo los punteros Sig desde Arr[Frente] debe llegar a -1 en exactamente (Final - Frente + 1) pasos, y siguiendo los punteros Ant desde Arr[Final] debe llegar a -1 en exactamente (Final - Frente + 1) pasos.

**Validates: Requirements 3.3**

### Property 11: Cola llena es detectada correctamente

*For any* cola con Tmax elementos insertados, ColaLlena() debe retornar true, y cualquier intento de inserción adicional debe ser rechazado.

**Validates: Requirements 4.1, 4.2**

### Property 12: Cola no llena permite inserciones

*For any* cola con menos de Tmax elementos, ColaLlena() debe retornar false, y la inserción debe tener éxito.

**Validates: Requirements 4.3**

## Error Handling

### ColaSimpleArr
- **Cola vacía**: Operaciones de eliminación y mostrar frente deben verificar ColaVacia() y mostrar mensaje de error
- **Cola llena**: Operaciones de inserción deben verificar ColaLlena() y mostrar mensaje de error
- **Índices fuera de rango**: No deben ocurrir si las operaciones son correctas

### ColaDobleE
- **Cola vacía**: Operaciones de eliminación y listado deben verificar ColaVacia() y mostrar mensaje de error
- **Cola llena**: Operaciones de inserción deben verificar ColaLlena() y mostrar mensaje de error
- **Punteros inconsistentes**: Los tests deben detectar cualquier inconsistencia en Ant/Sig

## Testing Strategy

### Unit Testing Framework
Se utilizará **JUnit 5** para las pruebas unitarias en Java.

### Property-Based Testing Framework
Se utilizará **jqwik** (https://jqwik.net/), una biblioteca de property-based testing para Java que se integra con JUnit 5.

### Configuración
- Cada property-based test debe ejecutar un mínimo de **100 iteraciones**
- Cada test debe estar etiquetado con un comentario que referencie la propiedad del diseño
- Formato del tag: `// Feature: queue-system-fix, Property X: [descripción]`

### Unit Tests
Los unit tests cubrirán:
- Casos específicos de inserción del primer elemento (Requirements 1.2)
- Casos específicos de eliminación del último elemento (Requirements 1.5)
- Casos específicos de cola vacía en operaciones de listado (Requirements 3.4)
- Casos de borde: insertar en cola llena, eliminar de cola vacía

### Property-Based Tests
Los property-based tests cubrirán:
- Todas las propiedades de correctitud listadas arriba (Properties 1-12)
- Generación aleatoria de secuencias de operaciones (insertar, eliminar, listar)
- Verificación de invariantes después de cada operación
- Detección de ciclos en recorridos

### Test Organization
```
test/
  proyecto9/
    ColaSimpleArrTest.java          // Unit tests para Cola Simple
    ColaDobleETest.java              // Unit tests para Cola Doble
    ColaSimpleArrPropertyTest.java   // Property tests para Cola Simple
    ColaDobleEPropertyTest.java      // Property tests para Cola Doble
    AlumnoGenerator.java             // Generador de objetos Alumno aleatorios
```

### Estrategia de Validación
1. **Corrección primero**: Corregir los bugs identificados en ColaSimpleArr y ColaDobleE
2. **Unit tests**: Escribir tests unitarios para casos específicos
3. **Property tests**: Escribir property tests para verificar propiedades universales
4. **Integración**: Verificar que el menú principal funciona correctamente con las colas corregidas
5. **Validación manual**: Ejecutar el programa y probar manualmente las operaciones

### Limitaciones Conocidas
La implementación actual **no usa índices circulares**, lo que significa que:
- Una vez que Final alcanza Tmax, no se pueden insertar más elementos aunque se hayan eliminado elementos del frente
- Esto es una limitación del diseño original que se respeta según los requisitos
- Los tests documentarán esta limitación pero no la corregirán
