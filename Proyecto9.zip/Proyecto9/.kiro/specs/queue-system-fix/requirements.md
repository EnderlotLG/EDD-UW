# Requirements Document

## Introduction

Este documento especifica los requisitos para corregir y hacer funcional un sistema de colas (Queue) en Java que incluye una Cola Doble (Deque) y una Cola Simple. El sistema debe manejar objetos Alumno sin ciclos infinitos y con comportamiento correcto según las estructuras de datos.

## Glossary

- **Cola Simple (ColaSimpleArr)**: Estructura de datos FIFO (First In, First Out) implementada con arreglo donde los elementos se insertan por el final y se eliminan por el frente
- **Cola Doble (ColaDobleE)**: Estructura de datos que permite inserción y eliminación tanto por el frente como por el final
- **Alumno**: Objeto que representa un estudiante con datos personales y punteros de enlace (Ant/Sig)
- **Frente**: Índice que apunta al primer elemento de la cola
- **Final**: Índice que apunta a la posición después del último elemento de la cola
- **Ciclo**: Condición donde un bucle o recorrido nunca termina debido a referencias circulares o condiciones incorrectas

## Requirements

### Requirement 1

**User Story:** Como usuario del sistema, quiero que la Cola Simple funcione correctamente como estructura FIFO, para que pueda insertar elementos por el final y eliminarlos por el frente sin errores.

#### Acceptance Criteria

1. WHEN la cola está vacía (Frente == -1 y Final == -1), THEN el sistema SHALL retornar verdadero en ColaVacia()
2. WHEN se inserta el primer elemento en una cola vacía, THEN el sistema SHALL establecer Frente = 0 y Final = 1
3. WHEN se insertan elementos subsecuentes, THEN el sistema SHALL incrementar Final y mantener Frente sin cambios
4. WHEN se elimina un elemento, THEN el sistema SHALL incrementar Frente
5. WHEN se elimina el último elemento, THEN el sistema SHALL establecer Frente = -1 y Final = -1

### Requirement 2

**User Story:** Como usuario del sistema, quiero que la Cola Doble funcione correctamente con inserción/eliminación bidireccional, para que pueda manipular elementos desde ambos extremos sin ciclos.

#### Acceptance Criteria

1. WHEN la cola está vacía (Frente == -1 y Final == -1), THEN el sistema SHALL retornar verdadero en ColaVacia()
2. WHEN se inserta por el frente en una cola no vacía, THEN el sistema SHALL actualizar correctamente los punteros Ant y Sig de todos los elementos afectados
3. WHEN se inserta por el final, THEN el sistema SHALL actualizar los punteros del elemento anterior y del nuevo elemento
4. WHEN se elimina por el frente, THEN el sistema SHALL incrementar Frente y actualizar el puntero Ant del nuevo frente a -1
5. WHEN se elimina por el final, THEN el sistema SHALL decrementar Final y actualizar el puntero Sig del nuevo final a -1

### Requirement 3

**User Story:** Como usuario del sistema, quiero que las operaciones de listado no entren en ciclos infinitos, para que pueda visualizar los elementos de la cola de manera segura.

#### Acceptance Criteria

1. WHEN se lista una cola de frente a final, THEN el sistema SHALL recorrer desde Frente hasta Final sin exceder los límites del arreglo
2. WHEN se lista una cola de final a frente, THEN el sistema SHALL recorrer desde Final hasta Frente sin exceder los límites del arreglo
3. WHEN se recorre la cola usando punteros Ant/Sig, THEN el sistema SHALL terminar cuando encuentre -1
4. WHEN la cola está vacía, THEN el sistema SHALL no intentar recorrer elementos
5. WHEN se detecta un índice fuera de rango, THEN el sistema SHALL detener el recorrido

### Requirement 4

**User Story:** Como usuario del sistema, quiero que la detección de cola llena sea precisa, para que el sistema no permita inserciones cuando no hay espacio disponible.

#### Acceptance Criteria

1. WHEN el número de elementos en la cola alcanza Tmax, THEN el sistema SHALL retornar verdadero en ColaLlena()
2. WHEN se intenta insertar en una cola llena, THEN el sistema SHALL rechazar la operación y mostrar un mensaje de error
3. WHEN Final - Frente es menor que Tmax, THEN el sistema SHALL permitir inserciones
4. WHEN la cola usa índices circulares, THEN el sistema SHALL calcular correctamente el espacio disponible
5. WHEN se elimina un elemento de una cola llena, THEN el sistema SHALL permitir nuevas inserciones

### Requirement 5

**User Story:** Como desarrollador, quiero tests automatizados que verifiquen el comportamiento correcto de las colas, para que pueda confirmar que no hay ciclos ni errores lógicos.

#### Acceptance Criteria

1. WHEN se ejecutan los tests de inserción, THEN el sistema SHALL verificar que los índices Frente y Final son correctos después de cada operación
2. WHEN se ejecutan los tests de eliminación, THEN el sistema SHALL verificar que la cola mantiene su integridad
3. WHEN se ejecutan los tests de listado, THEN el sistema SHALL verificar que el recorrido termina correctamente
4. WHEN se ejecutan tests de operaciones mixtas, THEN el sistema SHALL verificar que no hay ciclos en los punteros Ant/Sig
5. WHEN se ejecutan tests de casos límite, THEN el sistema SHALL manejar correctamente colas vacías y llenas
