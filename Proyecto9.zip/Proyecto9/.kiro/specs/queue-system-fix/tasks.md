# Implementation Plan

- [x] 1. Configurar dependencias de testing





  - Agregar JUnit 5 y jqwik al proyecto en build.xml
  - Crear estructura de directorios para tests
  - _Requirements: 5.1, 5.2, 5.3, 5.4, 5.5_

- [x] 2. Corregir ColaSimpleArr





  - Corregir el método ColaVacia() para usar `Frente == -1 && Final == -1`
  - Corregir el método Insertar() para manejar correctamente el primer elemento
  - Asegurar que Final apunta a la siguiente posición libre
  - _Requirements: 1.1, 1.2, 1.3_

- [x] 2.1 Escribir property test para detección de cola vacía






  - **Property 1: Cola vacía es detectada correctamente**
  - **Validates: Requirements 1.1**

- [ ] 2.2 Escribir property test para inserciones subsecuentes




  - **Property 2: Inserciones subsecuentes incrementan Final**
  - **Validates: Requirements 1.3**

- [ ]* 2.3 Escribir unit test para primer elemento
  - Verificar que al insertar el primer elemento Frente=0 y Final=1
  - _Requirements: 1.2_

- [ ]* 2.4 Escribir property test para eliminaciones
  - **Property 3: Eliminaciones incrementan Frente**
  - **Validates: Requirements 1.4**

- [ ]* 2.5 Escribir unit test para último elemento
  - Verificar que al eliminar el último elemento Frente=-1 y Final=-1
  - _Requirements: 1.5_

- [x] 3. Corregir ColaDobleE






  - Corregir el método ColaLlena() para usar `(Final - Frente + 1) >= Tmax`
  - Corregir InsertaFrente() para actualizar correctamente todos los punteros Ant/Sig
  - Verificar que InsertaFinal() actualiza correctamente los punteros
  - Verificar que EliminarFrente() actualiza Ant del nuevo frente a -1
  - Verificar que EliminarFinal() actualiza Sig del nuevo final a -1
  - _Requirements: 2.1, 2.2, 2.3, 2.4, 2.5_

- [ ]* 3.1 Escribir property test para inserción por el frente
  - **Property 4: Punteros consistentes después de insertar por el frente**
  - **Validates: Requirements 2.2**

- [ ]* 3.2 Escribir property test para inserción por el final
  - **Property 5: Punteros consistentes después de insertar por el final**
  - **Validates: Requirements 2.3**

- [ ]* 3.3 Escribir property test para eliminación por el frente
  - **Property 6: Eliminación por el frente actualiza punteros**
  - **Validates: Requirements 2.4**

- [ ]* 3.4 Escribir property test para eliminación por el final
  - **Property 7: Eliminación por el final actualiza punteros**
  - **Validates: Requirements 2.5**

- [x] 4. Implementar validaciones anti-ciclos en métodos de listado






  - Agregar verificación de límites en ListarFrenteaFinal()
  - Agregar verificación de límites en ListarFinalFrente()
  - Agregar contador de iteraciones para detectar ciclos infinitos
  - _Requirements: 3.1, 3.2, 3.3, 3.5_

- [ ]* 4.1 Escribir property test para listado frente a final
  - **Property 8: Listado de frente a final termina sin ciclos**
  - **Validates: Requirements 3.1**

- [ ]* 4.2 Escribir property test para listado final a frente
  - **Property 9: Listado de final a frente termina sin ciclos**
  - **Validates: Requirements 3.2**

- [ ]* 4.3 Escribir property test para recorrido por punteros
  - **Property 10: Recorrido por punteros no tiene ciclos**
  - **Validates: Requirements 3.3**

- [ ]* 4.4 Escribir unit test para cola vacía en listado
  - Verificar que listar una cola vacía no causa errores
  - _Requirements: 3.4_

- [x] 5. Validar detección de cola llena





  - Verificar que ColaLlena() funciona correctamente en ambas clases
  - Asegurar que las inserciones en cola llena son rechazadas
  - _Requirements: 4.1, 4.2, 4.3_

- [ ]* 5.1 Escribir property test para detección de cola llena
  - **Property 11: Cola llena es detectada correctamente**
  - **Validates: Requirements 4.1, 4.2**

- [ ]* 5.2 Escribir property test para cola no llena
  - **Property 12: Cola no llena permite inserciones**
  - **Validates: Requirements 4.3**

- [ ]* 5.3 Escribir property test para limitación de diseño
  - Documentar que eliminar de una cola llena puede no permitir nuevas inserciones
  - _Requirements: 4.5_

- [ ] 6. Crear generador de datos aleatorios para property tests
  - Implementar AlumnoGenerator para generar objetos Alumno aleatorios
  - Implementar generadores de secuencias de operaciones (insertar/eliminar)
  - _Requirements: 5.1, 5.2, 5.3, 5.4, 5.5_

- [ ] 7. Checkpoint - Ejecutar todos los tests
  - Ensure all tests pass, ask the user if questions arise.

- [ ]* 8. Escribir tests de integración
  - Crear tests que simulen secuencias completas de operaciones del menú
  - Verificar que las operaciones mixtas mantienen la integridad de las colas
  - _Requirements: 5.4_

- [x] 9. Completar y verificar la funcionalidad del programa principal






  - Revisar que todas las opciones del menú estén implementadas correctamente
  - Asegurar que la lógica de inserción/eliminación en ambas colas funciona sin errores
  - Verificar que los métodos de listado muestran la información correctamente
  - Completar cualquier funcionalidad faltante respetando el código fuente original
  - Asegurar que el programa no se cicla en ninguna operación
  - _Requirements: 1.1, 1.2, 1.3, 1.4, 1.5, 2.1, 2.2, 2.3, 2.4, 2.5, 3.1, 3.2, 3.4, 4.1, 4.2_

- [x] 10. Validación manual del programa completo





  - Ejecutar Proyecto9 y probar manualmente cada opción del menú
  - Insertar elementos por frente y final
  - Eliminar elementos por frente y final
  - Listar en ambas direcciones
  - Verificar comportamiento con colas vacías y llenas
  - Confirmar que no hay ciclos infinitos en ninguna operación
  - Verificar que los mensajes de error son apropiados
  - _Requirements: 1.1, 1.2, 1.3, 1.4, 1.5, 2.1, 2.2, 2.3, 2.4, 2.5, 3.1, 3.2, 3.4, 4.1, 4.2_

- [x] 11. Checkpoint final - Verificar que todo funciona





  - Ensure all tests pass, ask the user if questions arise.
