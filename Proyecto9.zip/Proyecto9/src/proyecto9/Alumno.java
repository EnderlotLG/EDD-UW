package proyecto9;

/**
 * Clase Alumno
 * @author fdogs
 */
public class Alumno {
    private String Nc;
    private String Nom;
    private String Dom;
    private String Tel;
    private String Email;
    private int Ant;
    private int Sig;
    
    public String getNc() {
        return Nc;
    }
    public void setNc(String Nc) {
        this.Nc = Nc;
    }
    public String getNom() {
        return Nom;
    }
    public void setNom(String Nom) {
        this.Nom = Nom;
    }
    public String getDom() {
        return Dom;
    }
    public void setDom(String Dom) {
        this.Dom = Dom;
    }
    public String getTel() {
        return Tel;
    }
    public void setTel(String Tel) {
        this.Tel = Tel;
    }
    public String getEmail() {
        return Email;
    }
    public void setEmail(String Email) {
        this.Email = Email;
    }
    public int getAnt() {
        return Ant;
    }
    public void setAnt(int Ant) {
        this.Ant = Ant;
    }
    public int getSig() {
        return Sig;
    }
    public void setSig(int Sig) {
        this.Sig = Sig;
    }
    public Alumno(String Nc, String Nom, String Dom, String Tel, String Email, int Ant, int Sig) {
        this.Nc = Nc;
        this.Nom = Nom;
        this.Dom = Dom;
        this.Tel = Tel;
        this.Email = Email;
        this.Ant = Ant;
        this.Sig = Sig;
    }
    public Alumno() {
    }
}