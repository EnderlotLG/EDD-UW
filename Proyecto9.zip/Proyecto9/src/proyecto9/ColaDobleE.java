
package proyecto9;

import proyecto9.Alumno;

public class ColaDobleE {
    private Alumno[] Arr = new Alumno[10];
    private int Frente;
    private int Final;
    private int Tmax;
    
    public int getFrente() {
        return Frente;
    }
    public void setFrente(int Frente) {
        this.Frente = Frente;
    }
    public int getFinal() {
        return Final;
    }
    public void setFinal(int Final) {
        this.Final = Final;
    }
    public int getTmax() {
        return Tmax;
    }
    public void setTmax(int Tmax) {
        this.Tmax = Tmax;
    }
    
    public ColaDobleE(int Frente, int Final, int Tmax) {
        this.Frente = Frente;
        this.Final = Final;
        this.Tmax = Tmax;
        for (int j = 0; j < 10; j++) {
            Arr[j] = new Alumno();
        }
    }
    
    public boolean ColaVacia() {
        return Frente == -1 && Final == -1;
    }
    
    public boolean ColaLlena() {
        if (Frente == -1 && Final == -1) return false;
        return (Final - Frente + 1) >= Tmax;
    }
    
    public void ListarFrenteaFinal() {
        // Validación de cola vacía
        if (ColaVacia()) {
            System.out.println("Cola vacía");
            return;
        }
        
        // Validación de límites del arreglo
        if (Frente < 0 || Frente >= Arr.length || Final < 0 || Final >= Arr.length) {
            System.out.println("ERROR: Índices fuera de rango");
            return;
        }
        
        // Contador de iteraciones para detectar ciclos infinitos
        int maxIteraciones = Tmax + 1; // No debería haber más elementos que Tmax
        int contador = 0;
        
        for (int j = Frente; j <= Final; j++) {
            // Verificación de límites en cada iteración
            if (j < 0 || j >= Arr.length) {
                System.out.println("ERROR: Índice fuera de rango durante recorrido");
                break;
            }
            
            // Verificación de ciclo infinito
            contador++;
            if (contador > maxIteraciones) {
                System.out.println("ERROR: Ciclo infinito detectado en ListarFrenteaFinal");
                break;
            }
            
            System.out.print(Arr[j].getAnt() + "\t");
            System.out.print(Arr[j].getNc() + "\t");
            System.out.print(Arr[j].getNom() + "\t");
            System.out.print(Arr[j].getDom() + "\t");
            System.out.print(Arr[j].getTel() + "\t");
            System.out.print(Arr[j].getEmail() + "\t");
            System.out.println(Arr[j].getSig()+ "\t");
        }
    }
    
    public void ListarFinalFrente() {
        // Validación de cola vacía
        if (ColaVacia()) {
            System.out.println("Cola vacía");
            return;
        }
        
        // Validación de límites del arreglo
        if (Frente < 0 || Frente >= Arr.length || Final < 0 || Final >= Arr.length) {
            System.out.println("ERROR: Índices fuera de rango");
            return;
        }
        
        // Contador de iteraciones para detectar ciclos infinitos
        int maxIteraciones = Tmax + 1; // No debería haber más elementos que Tmax
        int contador = 0;
        
        for (int j = Final; j >= Frente; j--) {
            // Verificación de límites en cada iteración
            if (j < 0 || j >= Arr.length) {
                System.out.println("ERROR: Índice fuera de rango durante recorrido");
                break;
            }
            
            // Verificación de ciclo infinito
            contador++;
            if (contador > maxIteraciones) {
                System.out.println("ERROR: Ciclo infinito detectado en ListarFinalFrente");
                break;
            }
            
            System.out.print(Arr[j].getAnt() + "\t");
            System.out.print(Arr[j].getNc() + "\t");
            System.out.print(Arr[j].getNom() + "\t");
            System.out.print(Arr[j].getDom() + "\t");
            System.out.print(Arr[j].getTel() + "\t");
            System.out.print(Arr[j].getEmail() + "\t");
            System.out.println(Arr[j].getSig()+ "\t");
        }
    }
    
    public void InsertaFrente(Alumno Nuevo) {
        if (ColaLlena()) {
            System.out.println("ERROR: Cola llena");
            return;
        }
        
        if (ColaVacia()) {
            Frente = 0;
            Final = 0;
            Nuevo.setAnt(-1);
            Nuevo.setSig(-1);
            Arr[0] = Nuevo;
        } else {
            // mueve todos los elementos una posición hacia adelante
            for(int j = Final; j >= Frente; j--){
                Arr[j + 1] = Arr[j];
            }
            Final++;
            
            // Actualiza todos los punteros después de mover
            for(int j = Frente + 1; j <= Final; j++){
                if (j == Final) {
                    Arr[j].setSig(-1);
                } else {
                    Arr[j].setSig(j + 1);
                }
                Arr[j].setAnt(j - 1);
            }
            
            // Inserta el nuevo elemento al frente
            Arr[Frente] = Nuevo;
            Arr[Frente].setAnt(-1);
            Arr[Frente].setSig(Frente + 1);
        }
    }
    
    public void InsertaFinal(Alumno Nuevo) {
        if (ColaLlena()) {
            System.out.println("ERROR: Cola llena");
            return;
        }
        
        if (ColaVacia()) {
            Frente = 0;
            Final = 0;
            Nuevo.setAnt(-1);
            Nuevo.setSig(-1);
            Arr[0] = Nuevo;
        } else {
            Final++;
            Nuevo.setAnt(Final - 1);
            Nuevo.setSig(-1);
            Arr[Final] = Nuevo;
            Arr[Final - 1].setSig(Final);
        }
    }
    
    public void EliminarFrente() {
        if (ColaVacia()) {
            System.out.println("ERROR: Cola vacía");
            return;
        }
        
        if (Frente == Final) {
            // solo  un elemento
            Frente = -1;
            Final = -1;
        } else {
            Frente++;
            Arr[Frente].setAnt(-1);
        }
    }
    
    public void EliminarFinal() {
        if (ColaVacia()) {
            System.out.println("ERROR: Cola vacía");
            return;
        }
        
        if (Frente == Final) {
            // Solo  un elemento
            Frente = -1;
            Final = -1;
        } else {
            Arr[Final - 1].setSig(-1);
            Final--;
        }
    }
    
    public void Eliminar() {
        EliminarFrente();
    }
    
    public void MostrarFrente() {
        if (ColaVacia()) {
            System.out.println("Cola vacía");
        } else {
            System.out.println("\n--- Frente de la Cola ---");
            System.out.print(Arr[Frente].getAnt() + "\t");
            System.out.print(Arr[Frente].getNc() + "\t");
            System.out.print(Arr[Frente].getNom() + "\t");
            System.out.print(Arr[Frente].getDom() + "\t");
            System.out.print(Arr[Frente].getTel() + "\t");
            System.out.print(Arr[Frente].getEmail() + "\t");
            System.out.println(Arr[Frente].getSig());
        }
    }
    
    public void Insertar(Alumno Nuevo) {
        InsertaFinal(Nuevo);
    }
    
    public void ListarCola() {
        ListarFrenteaFinal();
    }
}