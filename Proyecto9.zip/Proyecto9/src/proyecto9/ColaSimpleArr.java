package proyecto9;

/*
 * @author fdogs
 */
public class ColaSimpleArr {
    private Alumno[] Arr = new Alumno[10];
    private int Frente;
    private int Final;
    private int Tmax;
    
    public int getFrente() {
        return Frente;
    }
    public void setFrente(int Frente) {
        this.Frente = Frente;
    }
    public int getFinal() {
        return Final;
    }
    public void setFinal(int Final) {
        this.Final = Final;
    }
    public int getTmax() {
        return Tmax;
    }
    public void setTmax(int Tmax) {
        this.Tmax = Tmax;
    }
    
    // Constructor
    public ColaSimpleArr(int Tmax) {
        this.Frente = -1;
        this.Final = -1;
        this.Tmax = Tmax;
        for (int j = 0; j < 10; j++) {
            Arr[j] = new Alumno();
        }
    }
    
    public boolean ColaVacia() {
        return Frente == -1 && Final == -1;
    }
    
    public boolean ColaLlena() {
        return Final == Tmax;
    }
    
    /**
     * Inserta un elemento en la cola (siempre por el FINAL)
     */
    public void Insertar(Alumno Nuevo) {
        if (ColaLlena()) {
            System.out.println("ERROR: Cola llena");
            return;
        }
        
        if (ColaVacia()) {
            Frente = 0;
            Final = 0;
            Arr[0] = Nuevo;
            Final++;
        } else {
            Arr[Final] = Nuevo;
            Final++;
        }
    }
    
    /**
     * Elimina un elemento de la cola (siempre por el FRENTE)
     */
    public void Eliminar() {
        if (ColaVacia()) {
            System.out.println("ERROR: Cola vacía");
            return;
        }
        
        if (Frente == Final - 1) {  // Solo hay un elemento
            Frente = -1;
            Final = -1;
        } else {
            Frente++;
        }
    }
    
    /**
     * Muestra el elemento del FRENTE sin eliminarlo
     */
    public void MostrarFrente() {
        if (ColaVacia()) {
            System.out.println("Cola vacía");
        } else {
            System.out.println("\n--- Frente de Cola Simple ---");
            System.out.print(Arr[Frente].getNc() + "\t");
            System.out.print(Arr[Frente].getNom() + "\t");
            System.out.print(Arr[Frente].getDom() + "\t");
            System.out.print(Arr[Frente].getTel() + "\t");
            System.out.println(Arr[Frente].getEmail());
        }
    }
    
    /**
     * Lista todos los elementos de la cola
     */
    public void ListarCola() {
        if (ColaVacia()) {
            System.out.println("Cola vacía");
            return;
        }
        
        System.out.println("\n--- Elementos en Cola Simple ---");
        System.out.println("NC\tNombre\tDomicilio\tTeléfono\tEmail");
        System.out.println("-------------------------------------------------------");
        
        for (int j = Frente; j < Final; j++) {
            System.out.print(Arr[j].getNc() + "\t");
            System.out.print(Arr[j].getNom() + "\t");
            System.out.print(Arr[j].getDom() + "\t");
            System.out.print(Arr[j].getTel() + "\t");
            System.out.println(Arr[j].getEmail());
        }
    }
}