
package proyecto9;
import java.util.Scanner;

/**
 * 
 * @author fdogs
 */
public class Proyecto9 {
    static Scanner s = new Scanner(System.in);
    static ColaDobleE CDE = new ColaDobleE(-1, -1, 3);      // Cola Doble con arreglos
    static ColaSimpleArr CDE_Arr = new ColaSimpleArr(3);     // Cola Simple con arreglos
    
    public static void main(String[] args) {
        int op = 0;
        while (op != 7) {  
            System.out.println("\n=== MENU COLA DOBLE ===");
            System.out.println("1. Insertar Por el Frente");
            System.out.println("2. Insertar por el Final");
            System.out.println("3. Eliminar por el Frente");
            System.out.println("4. Eliminar por el Final");
            System.out.println("5. Listar Frente a Final");
            System.out.println("6. Listar Final a Frente");
            System.out.println("7. Salir");
            System.out.print("Opcion: ");
            op = s.nextInt();
            
            switch (op) {
                case 1: // INSERTAR POR EL FRENTE
                    if (CDE.ColaLlena() && CDE_Arr.ColaLlena()) {
                        System.out.println("Ambas colas están llenas");
                    } else {
                        Alumno Nuevo = new Alumno();
                        System.out.print("Numero de Control: ");
                        Nuevo.setNc(s.next());
                        System.out.print("Nombre: ");
                        Nuevo.setNom(s.next());
                        System.out.print("Domicilio: ");
                        Nuevo.setDom(s.next());
                        System.out.print("Telefono: ");
                        Nuevo.setTel(s.next());
                        System.out.print("Email: ");
                        Nuevo.setEmail(s.next());
                        Nuevo.setAnt(-1);
                        Nuevo.setSig(-1);
                        
                        // Insertar en Cola Doble por el FRENTE
                        if (!CDE.ColaLlena()) {
                            CDE.InsertaFrente(Nuevo);
                        }
                        
                        // Insertar en Cola Simple (siempre por el final)
                        if (!CDE_Arr.ColaLlena()) {
                            CDE_Arr.Insertar(Nuevo);
                        }
                        
                        System.out.println("Alumno agregado exitosamente.");
                    }
                    break;
                    
                case 2: // INSERTAR POR EL FINAL
                    if (CDE.ColaLlena() && CDE_Arr.ColaLlena()) {
                        System.out.println("Ambas colas están llenas");
                    } else {
                        Alumno Nuevo = new Alumno();
                        System.out.print("Numero de Control: ");
                        Nuevo.setNc(s.next());
                        System.out.print("Nombre: ");
                        Nuevo.setNom(s.next());
                        System.out.print("Domicilio: ");
                        Nuevo.setDom(s.next());
                        System.out.print("Telefono: ");
                        Nuevo.setTel(s.next());
                        System.out.print("Email: ");
                        Nuevo.setEmail(s.next());
                        Nuevo.setAnt(-1);
                        Nuevo.setSig(-1);
                        
                        // Insertar en Cola Doble por el FINAL
                        if (!CDE.ColaLlena()) {
                            CDE.InsertaFinal(Nuevo);
                        }
                        
                        // Insertar en Cola Simple (siempre por el final)
                        if (!CDE_Arr.ColaLlena()) {
                            CDE_Arr.Insertar(Nuevo);
                        }
                        
                        System.out.println("Alumno agregado exitosamente.");
                    }
                    break;
                    
                case 3: // ELIMINAR POR EL FRENTE
                    if (CDE.ColaVacia() && CDE_Arr.ColaVacia()) {
                        System.out.println("Ambas están vacías");
                    } else {
                        if (!CDE.ColaVacia()) {
                            System.out.println("\n--- Eliminando de Cola Doble ---");
                            CDE.MostrarFrente();
                            CDE.EliminarFrente();
                        }
                        
                        if (!CDE_Arr.ColaVacia()) {
                            System.out.println("\n--- Eliminando de Cola Simple ---");
                            CDE_Arr.MostrarFrente();
                            CDE_Arr.Eliminar();
                        }
                        System.out.println("Elemento(s) eliminado(s)");
                    }
                    break;
                    
                case 4: // ELIMINAR POR EL FINAL
                    if (CDE.ColaVacia()) {
                        System.out.println("Cola Doble está vacía");
                    } else {
                        System.out.println("\n--- Eliminando del Final de Cola Doble ---");
                        CDE.EliminarFinal();
                        System.out.println("Elemento eliminado del final");
                    }
                    break;
                    
                case 5: // LISTAR FRENTE A FINAL
                    if (CDE.ColaVacia() && CDE_Arr.ColaVacia()) {
                        System.out.println("Ambas colas están vacías");
                    } else {
                        if (!CDE.ColaVacia()) {
                            System.out.println("\n=== Cola Doble (Frente → Final) ===");
                            CDE.ListarFrenteaFinal();
                        }
                        
                        if (!CDE_Arr.ColaVacia()) {
                            System.out.println("\n=== Cola Simple ===");
                            CDE_Arr.ListarCola();
                        }
                    }
                    break;
                    
                case 6: // LISTAR FINAL A FRENTE
                    if (CDE.ColaVacia()) {
                        System.out.println("Cola Doble está vacía");
                    } else {
                        System.out.println("\n=== Cola Doble (Final → Frente) ===");
                        CDE.ListarFinalFrente();
                    }
                    break;
                    
                case 7:
                    System.out.println("Saliendo del programa...");
                    break;
                    
                default:
                    System.out.println("Opción inválida. Intente de nuevo.");
                    break;
            }
        }
        s.close();
    }
}