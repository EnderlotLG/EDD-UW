
package proyectolcirculares;

/**
 *Clase Alumno - Tipo de Dato Abstracto (TDA)
 * Representa la información de un alumno con enlaces para lista circular
 * 
 * @author fdogs
 */

public class Alumno {
     // Atributos de información del alumno
    private String nc;          // Número de control
    private String nom;         // Nombre completo
    private String dom;         // Domicilio
    private String tel;         // Teléfono
    private String email;       // Correo electrónico
    
    // Atributos para manejo de lista circular
    private Alumno anterior;    // Puntero al nodo anterior (para memoria dinámica)
    private Alumno siguiente;   // Puntero al nodo siguiente (para memoria dinámica)
    private int indiceAnt;      // Índice del elemento anterior (para memoria estática)
    private int indiceSig;      // Índice del elemento siguiente (para memoria estática)

    /**
     * Constructor completo para memoria dinámica
     * @param nc Número de control del alumno
     * @param nom Nombre completo del alumno
     * @param dom Domicilio del alumno
     * @param tel Teléfono del alumno
     * @param email Email del alumno
     */
    public Alumno(String nc, String nom, String dom, String tel, String email) {
        this.nc = nc;
        this.nom = nom;
        this.dom = dom;
        this.tel = tel;
        this.email = email;
        this.anterior = null;
        this.siguiente = null;
        this.indiceAnt = -1;
        this.indiceSig = -1;
    }

    /**
     * Constructor vacío - inicializa con valores por defecto
     */
    public Alumno() {
        this.nc = "";
        this.nom = "";
        this.dom = "";
        this.tel = "";
        this.email = "";
        this.anterior = null;
        this.siguiente = null;
        this.indiceAnt = -1;
        this.indiceSig = -1;
    }

    // ==================== GETTERS Y SETTERS ====================
    
    /**
     * Obtiene el número de control del alumno
     * @return String con el número de control
     */
    public String getNc() {
        return nc;
    }

    /**
     * Establece el número de control del alumno
     * @param nc Nuevo número de control
     */
    public void setNc(String nc) {
        this.nc = nc;
    }

    /**
     * Obtiene el nombre del alumno
     * @return String con el nombre completo
     */
    public String getNom() {
        return nom;
    }

    /**
     * Establece el nombre del alumno
     * @param nom Nuevo nombre completo
     */
    public void setNom(String nom) {
        this.nom = nom;
    }

    /**
     * Obtiene el domicilio del alumno
     * @return String con el domicilio
     */
    public String getDom() {
        return dom;
    }

    /**
     * Establece el domicilio del alumno
     * @param dom Nuevo domicilio
     */
    public void setDom(String dom) {
        this.dom = dom;
    }

    /**
     * Obtiene el teléfono del alumno
     * @return String con el teléfono
     */
    public String getTel() {
        return tel;
    }

    /**
     * Establece el teléfono del alumno
     * @param tel Nuevo teléfono
     */
    public void setTel(String tel) {
        this.tel = tel;
    }

    /**
     * Obtiene el email del alumno
     * @return String con el email
     */
    public String getEmail() {
        return email;
    }

    /**
     * Establece el email del alumno
     * @param email Nuevo email
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Obtiene el puntero al nodo anterior (memoria dinámica)
     * @return Referencia al alumno anterior
     */
    public Alumno getAnterior() {
        return anterior;
    }

    /**
     * Establece el puntero al nodo anterior (memoria dinámica)
     * @param anterior Referencia al nuevo alumno anterior
     */
    public void setAnterior(Alumno anterior) {
        this.anterior = anterior;
    }

    /**
     * Obtiene el puntero al nodo siguiente (memoria dinámica)
     * @return Referencia al alumno siguiente
     */
    public Alumno getSiguiente() {
        return siguiente;
    }

    /**
     * Establece el puntero al nodo siguiente (memoria dinámica)
     * @param siguiente Referencia al nuevo alumno siguiente
     */
    public void setSiguiente(Alumno siguiente) {
        this.siguiente = siguiente;
    }

    /**
     * Obtiene el índice del elemento anterior (memoria estática)
     * @return Índice del elemento anterior en el arreglo
     */
    public int getIndiceAnt() {
        return indiceAnt;
    }

    /**
     * Establece el índice del elemento anterior (memoria estática)
     * @param indiceAnt Nuevo índice del elemento anterior
     */
    public void setIndiceAnt(int indiceAnt) {
        this.indiceAnt = indiceAnt;
    }

    /**
     * Obtiene el índice del elemento siguiente (memoria estática)
     * @return Índice del elemento siguiente en el arreglo
     */
    public int getIndiceSig() {
        return indiceSig;
    }

    /**
     * Establece el índice del elemento siguiente (memoria estática)
     * @param indiceSig Nuevo índice del elemento siguiente
     */
    public void setIndiceSig(int indiceSig) {
        this.indiceSig = indiceSig;
    }

    /**
     * Verifica si el alumno está vacío (sin datos)
     * @return true si el número de control está vacío, false en caso contrario
     */
    public boolean estaVacio() {
        return this.nc == null || this.nc.trim().isEmpty();
    }

    /**
     * Representación en cadena del alumno para mostrar en consola
     * @return String formateado con los datos del alumno
     */
    @Override
    public String toString() {
        return String.format("%-15s %-20s %-25s %-15s %-25s",
                nc != null ? nc : "",
                nom != null ? nom : "",
                dom != null ? dom : "",
                tel != null ? tel : "",
                email != null ? email : "");
    }

    /**
     * Copia los datos de otro alumno (sin copiar los enlaces)
     * @param otro Alumno del cual copiar los datos
     */
    public void copiarDatos(Alumno otro) {
        if (otro != null) {
            this.nc = otro.nc;
            this.nom = otro.nom;
            this.dom = otro.dom;
            this.tel = otro.tel;
            this.email = otro.email;
        }
    }

    /**
     * Limpia todos los datos del alumno
     */
    public void limpiar() {
        this.nc = "";
        this.nom = "";
        this.dom = "";
        this.tel = "";
        this.email = "";
        this.anterior = null;
        this.siguiente = null;
        this.indiceAnt = -1;
        this.indiceSig = -1;
    }
}
