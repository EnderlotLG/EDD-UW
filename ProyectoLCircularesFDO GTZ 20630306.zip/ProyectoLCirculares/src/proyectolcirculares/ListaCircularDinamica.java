
package proyectolcirculares;

/**
 * * Implementación de Lista Circular Doblemente Enlazada con Memoria Dinámica
 * 
 * Esta clase implementa una lista circular donde cada nodo tiene referencias
 * tanto al nodo anterior como al siguiente, formando un círculo completo.
 * Utiliza punteros (referencias) para el manejo dinámico de memoria.
 * 
 * Características:
 * - Capacidad ilimitada (solo limitada por la memoria disponible)
 * - Navegación bidireccional (hacia adelante y hacia atrás)
 * - Estructura circular (el último nodo apunta al primero y viceversa)
 * 
 * @author fdogs
 */
public class ListaCircularDinamica {
   private Alumno inicio;      // Puntero al primer nodo de la lista
    private int contador;       // Número de elementos en la lista
    
    /**
     * Constructor - Inicializa una lista circular vacía
     */
    public ListaCircularDinamica() {
        this.inicio = null;
        this.contador = 0;
    }
    
    /**
     * Verifica si la lista está vacía
     * @return true si la lista no tiene elementos, false en caso contrario
     */
    public boolean listaVacia() {
        return inicio == null;
    }
    
    /**
     * Obtiene el número de elementos en la lista
     * @return Cantidad de elementos almacenados
     */
    public int getTamanio() {
        return contador;
    }
    
    /**
     * Obtiene el nodo de inicio de la lista
     * @return Referencia al primer nodo
     */
    public Alumno getInicio() {
        return inicio;
    }
    
    /**
     * Inserta un nuevo alumno al final de la lista circular
     * 
     * Proceso:
     * 1. Si la lista está vacía, el nuevo nodo se convierte en el único elemento
     *    y sus punteros anterior y siguiente apuntan a sí mismo
     * 2. Si la lista tiene elementos, se inserta al final y se actualizan
     *    todos los enlaces para mantener la circularidad
     * 
     * @param nuevo Alumno a insertar en la lista
     */
    public void insertar(Alumno nuevo) {
        if (nuevo == null) {
            System.out.println("Error: No se puede insertar un alumno nulo");
            return;
        }
        
        if (listaVacia()) {
            // Primer elemento: se apunta a sí mismo
            inicio = nuevo;
            nuevo.setAnterior(nuevo);
            nuevo.setSiguiente(nuevo);
        } else {
            // Obtener el último nodo (anterior al inicio)
            Alumno ultimo = inicio.getAnterior();
            
            // Configurar enlaces del nuevo nodo
            nuevo.setAnterior(ultimo);
            nuevo.setSiguiente(inicio);
            
            // Actualizar enlaces existentes
            ultimo.setSiguiente(nuevo);
            inicio.setAnterior(nuevo);
        }
        
        contador++;
        System.out.println("Alumno insertado correctamente. Total: " + contador);
    }
    
    /**
     * Busca un alumno por su número de control
     * 
     * @param nc Número de control a buscar
     * @return Referencia al alumno encontrado, null si no existe
     */
    public Alumno buscar(String nc) {
        if (listaVacia() || nc == null || nc.trim().isEmpty()) {
            return null;
        }
        
        Alumno actual = inicio;
        int visitados = 0;
        
        // Recorrer la lista circular
        do {
            if (actual.getNc().equals(nc)) {
                return actual;
            }
            actual = actual.getSiguiente();
            visitados++;
        } while (actual != inicio && visitados < contador);
        
        return null; // No encontrado
    }
    
    /**
     * Elimina un alumno de la lista por su número de control
     * 
     * Casos a considerar:
     * 1. Lista vacía: No hay nada que eliminar
     * 2. Un solo elemento: La lista queda vacía
     * 3. Múltiples elementos: Se reconfiguran los enlaces manteniendo la circularidad
     * 
     * @param nc Número de control del alumno a eliminar
     * @return true si se eliminó correctamente, false si no se encontró
     */
    public boolean eliminar(String nc) {
        if (listaVacia()) {
            System.out.println("Error: La lista está vacía");
            return false;
        }
        
        Alumno aEliminar = buscar(nc);
        if (aEliminar == null) {
            System.out.println("Error: Alumno con NC " + nc + " no encontrado");
            return false;
        }
        
        if (contador == 1) {
            // Único elemento en la lista
            inicio = null;
        } else {
            // Reconfigurar enlaces
            Alumno anterior = aEliminar.getAnterior();
            Alumno siguiente = aEliminar.getSiguiente();
            
            anterior.setSiguiente(siguiente);
            siguiente.setAnterior(anterior);
            
            // Si eliminamos el nodo de inicio, actualizar la referencia
            if (aEliminar == inicio) {
                inicio = siguiente;
            }
        }
        
        contador--;
        System.out.println("Alumno eliminado correctamente. Total: " + contador);
        return true;
    }
    
    /**
     * Modifica los datos de un alumno existente
     * 
     * @param nc Número de control del alumno a modificar
     * @param nuevosDatos Alumno con los nuevos datos
     * @return true si se modificó correctamente, false si no se encontró
     */
    public boolean modificar(String nc, Alumno nuevosDatos) {
        Alumno aModificar = buscar(nc);
        if (aModificar == null) {
            System.out.println("Error: Alumno con NC " + nc + " no encontrado");
            return false;
        }
        
        // Copiar solo los datos, mantener los enlaces
        aModificar.setNom(nuevosDatos.getNom());
        aModificar.setDom(nuevosDatos.getDom());
        aModificar.setTel(nuevosDatos.getTel());
        aModificar.setEmail(nuevosDatos.getEmail());
        
        System.out.println("Alumno modificado correctamente");
        return true;
    }
    
    /**
     * Lista todos los alumnos en sentido horario (hacia adelante)
     * Recorre desde el nodo de inicio siguiendo los punteros 'siguiente'
     */
    public void listarHorario() {
        if (listaVacia()) {
            System.out.println("La lista está vacía");
            return;
        }
        
        System.out.println("\n=== LISTADO HORARIO (Memoria Dinámica) ===");
        System.out.println(String.format("%-15s %-20s %-25s %-15s %-25s", 
            "No. Control", "Nombre", "Domicilio", "Teléfono", "Email"));
        System.out.println("=".repeat(105));
        
        Alumno actual = inicio;
        int visitados = 0;
        
        do {
            System.out.println(actual.toString());
            actual = actual.getSiguiente();
            visitados++;
        } while (actual != inicio && visitados < contador);
        
        System.out.println("=".repeat(105));
        System.out.println("Total de alumnos: " + contador);
    }
    
    /**
     * Lista todos los alumnos en sentido antihorario (hacia atrás)
     * Recorre desde el nodo de inicio siguiendo los punteros 'anterior'
     */
    public void listarAntihorario() {
        if (listaVacia()) {
            System.out.println("La lista está vacía");
            return;
        }
        
        System.out.println("\n=== LISTADO ANTIHORARIO (Memoria Dinámica) ===");
        System.out.println(String.format("%-15s %-20s %-25s %-15s %-25s", 
            "No. Control", "Nombre", "Domicilio", "Teléfono", "Email"));
        System.out.println("=".repeat(105));
        
        Alumno actual = inicio.getAnterior(); // Empezar desde el último
        int visitados = 0;
        
        do {
            System.out.println(actual.toString());
            actual = actual.getAnterior();
            visitados++;
        } while (actual != inicio.getAnterior() && visitados < contador);
        
        System.out.println("=".repeat(105));
        System.out.println("Total de alumnos: " + contador);
    }
    
    /**
     * Muestra información detallada del estado de la lista
     */
    public void mostrarEstado() {
        System.out.println("\n--- Estado de Lista Circular Dinámica ---");
        System.out.println("Tipo: Memoria Dinámica (Punteros)");
        System.out.println("Elementos: " + contador);
        System.out.println("Estado: " + (listaVacia() ? "Vacía" : "Con elementos"));
        
        if (!listaVacia()) {
            System.out.println("Primer elemento: " + inicio.getNc() + " - " + inicio.getNom());
            System.out.println("Último elemento: " + inicio.getAnterior().getNc() + 
                             " - " + inicio.getAnterior().getNom());
        }
    }
    
    /**
     * Limpia completamente la lista, eliminando todos los elementos
     */
    public void limpiar() {
        if (!listaVacia()) {
            // Romper los enlaces circulares para ayudar al garbage collector
            Alumno actual = inicio;
            do {
                Alumno siguiente = actual.getSiguiente();
                actual.setAnterior(null);
                actual.setSiguiente(null);
                actual = siguiente;
            } while (actual != inicio);
        }
        
        inicio = null;
        contador = 0;
        System.out.println("Lista limpiada correctamente");
    }
    
    /**
     * Verifica la integridad de la lista circular
     * Útil para debugging y verificar que los enlaces estén correctos
     * 
     * @return true si la lista es consistente, false si hay errores
     */
    public boolean verificarIntegridad() {
        if (listaVacia()) {
            return contador == 0;
        }
        
        if (contador == 1) {
            return inicio.getAnterior() == inicio && inicio.getSiguiente() == inicio;
        }
        
        Alumno actual = inicio;
        int contados = 0;
        
        do {
            // Verificar que los enlaces sean bidireccionales
            if (actual.getSiguiente().getAnterior() != actual) {
                System.out.println("Error: Enlace bidireccional roto en " + actual.getNc());
                return false;
            }
            
            actual = actual.getSiguiente();
            contados++;
            
            // Evitar bucle infinito
            if (contados > contador + 1) {
                System.out.println("Error: Bucle infinito detectado");
                return false;
            }
            
        } while (actual != inicio);
        
        return contados == contador;
    } 
}
