
package proyectolcirculares;

/**
 *
 * @author fdogs
 */
public class ListaCircularEstatica {
   private Alumno[] lista;
    private int inicio;
    private int tamanioMax;
    private int contador;
    
    public ListaCircularEstatica(int tamanioMax) {
        this.tamanioMax = tamanioMax;
        this.lista = new Alumno[tamanioMax];
        this.inicio = -1;
        this.contador = 0;
        
        for (int i = 0; i < tamanioMax; i++) {
            lista[i] = new Alumno();
        }
    }
    
    public boolean listaVacia() {
        return contador == 0;
    }
    
    public boolean listaLlena() {
        return contador == tamanioMax;
    }
    
    private int buscarPosicionLibre() {
        for (int i = 0; i < tamanioMax; i++) {
            if (lista[i].estaVacio()) {
                return i;
            }
        }
        return -1;
    }
    
    public void insertar(Alumno nuevo) {
        if (listaLlena()) {
            System.out.println("ERROR: Lista llena");
            return;
        }
        
        int posLibre = buscarPosicionLibre();
        if (posLibre == -1) {
            System.out.println("ERROR: No se encontró posición libre");
            return;
        }
        
        lista[posLibre].copiarDatos(nuevo);
        
        if (listaVacia()) {
            inicio = posLibre;
            lista[posLibre].setIndiceAnt(posLibre);
            lista[posLibre].setIndiceSig(posLibre);
        } else {
            int ultimoIndice = lista[inicio].getIndiceAnt();
            
            lista[posLibre].setIndiceAnt(ultimoIndice);
            lista[posLibre].setIndiceSig(inicio);
            lista[ultimoIndice].setIndiceSig(posLibre);
            lista[inicio].setIndiceAnt(posLibre);
        }
        
        contador++;
        System.out.println("Alumno insertado correctamente");
    }
    
    public int buscar(String nc) {
        if (listaVacia()) {
            return -1;
        }
        
        int actual = inicio;
        int visitados = 0;
        
        do {
            if (lista[actual].getNc().equals(nc)) {
                return actual;
            }
            actual = lista[actual].getIndiceSig();
            visitados++;
        } while (actual != inicio && visitados < contador);
        
        return -1;
    }
    
    public void eliminar(String nc) {
        if (listaVacia()) {
            System.out.println("ERROR: Lista vacía");
            return;
        }
        
        int indiceEliminar = buscar(nc);
        if (indiceEliminar == -1) {
            System.out.println("ERROR: Alumno no encontrado");
            return;
        }
        
        if (contador == 1) {
            lista[indiceEliminar].limpiar();
            inicio = -1;
        } else {
            int anterior = lista[indiceEliminar].getIndiceAnt();
            int siguiente = lista[indiceEliminar].getIndiceSig();
            
            lista[anterior].setIndiceSig(siguiente);
            lista[siguiente].setIndiceAnt(anterior);
            
            if (indiceEliminar == inicio) {
                inicio = siguiente;
            }
            
            lista[indiceEliminar].limpiar();
        }
        
        contador--;
        System.out.println("Alumno eliminado correctamente");
    }
    
    public void modificar(String nc, Alumno nuevosDatos) {
        int indice = buscar(nc);
        if (indice == -1) {
            System.out.println("ERROR: Alumno no encontrado");
            return;
        }
        
        int antOriginal = lista[indice].getIndiceAnt();
        int sigOriginal = lista[indice].getIndiceSig();
        
        lista[indice].copiarDatos(nuevosDatos);
        
        lista[indice].setIndiceAnt(antOriginal);
        lista[indice].setIndiceSig(sigOriginal);
        
        System.out.println("Alumno modificado correctamente");
    }
    
    public void listarHorario() {
        if (listaVacia()) {
            System.out.println("Lista vacía");
            return;
        }
        
        System.out.println("\n=== LISTADO HORARIO (Estática) ===");
        System.out.print("Ant\t");
        System.out.print("NC\t");
        System.out.print("Nom\t");
        System.out.print("Dom\t");
        System.out.print("Tel\t");
        System.out.print("Email\t");
        System.out.println("Sig");
        
        int actual = inicio;
        int visitados = 0;
        
        do {
            System.out.print(lista[actual].getIndiceAnt() + "\t");
            System.out.print(lista[actual].getNc() + "\t");
            System.out.print(lista[actual].getNom() + "\t");
            System.out.print(lista[actual].getDom() + "\t");
            System.out.print(lista[actual].getTel() + "\t");
            System.out.print(lista[actual].getEmail() + "\t");
            System.out.println(lista[actual].getIndiceSig());
            
            actual = lista[actual].getIndiceSig();
            visitados++;
        } while (actual != inicio && visitados < contador);
        
        System.out.println("Total: " + contador);
    }
    
    public void listarAntihorario() {
        if (listaVacia()) {
            System.out.println("Lista vacía");
            return;
        }
        
        System.out.println("\n=== LISTADO ANTIHORARIO (Estática) ===");
        System.out.print("Ant\t");
        System.out.print("NC\t");
        System.out.print("Nom\t");
        System.out.print("Dom\t");
        System.out.print("Tel\t");
        System.out.print("Email\t");
        System.out.println("Sig");
        
        int actual = lista[inicio].getIndiceAnt();
        int visitados = 0;
        
        do {
            System.out.print(lista[actual].getIndiceAnt() + "\t");
            System.out.print(lista[actual].getNc() + "\t");
            System.out.print(lista[actual].getNom() + "\t");
            System.out.print(lista[actual].getDom() + "\t");
            System.out.print(lista[actual].getTel() + "\t");
            System.out.print(lista[actual].getEmail() + "\t");
            System.out.println(lista[actual].getIndiceSig());
            
            actual = lista[actual].getIndiceAnt();
            visitados++;
        } while (actual != lista[inicio].getIndiceAnt() && visitados < contador);
        
        System.out.println("Total: " + contador);
    }
    
    public int getContador() {
        return contador;
    }
    
    public int getTamanioMax() {
        return tamanioMax;
    }
    
    public int getInicio() {
        return inicio;
    }  
}
