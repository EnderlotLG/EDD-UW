package listascirculares;

import java.util.Scanner;

/**
 * Implementación de Listas Circulares Doblemente Enlazadas
 * Comparación entre memoria estática (arreglos) y memoria dinámica (punteros)
 * 
 * @author fdogs
 */
public class ProyectoListasCirculares {
    
    public static Scanner s = new Scanner(System.in);
    public static ListaCircularEstatica LCE = new ListaCircularEstatica(10);
    public static ListaCircularDinamica LCD = new ListaCircularDinamica();
    
    public static void main(String[] args) {
        int op = 0;
        while (op != 7) {
            System.out.println("1. Agrega 2. Elimina 3. Modifica 4. Busca 5. Consulta Horario 6. Consulta Antihorario 7. Salir");
            op = s.nextInt();
            switch (op) {
                case 1:
                    System.out.println("Agrega alumnos");
                    if (LCE.listaLlena()) {
                        System.out.println("Lista estática llena");
                    }
                    
                    Alumno Nuevo = new Alumno();
                    System.out.println("Escribe el numero de control: ");
                    Nuevo.setNc(s.next());
                    System.out.println("Escribe el nombre: ");
                    Nuevo.setNom(s.next());
                    System.out.println("Escribe el domicilio: ");
                    Nuevo.setDom(s.next());
                    System.out.println("Escribe el numero de telefono: ");
                    Nuevo.setTel(s.next());
                    System.out.println("Escribe tu Email: ");
                    Nuevo.setEmail(s.next());
                    
                    if (!LCE.listaLlena()) {
                        LCE.insertar(Nuevo);
                    }
                    
                    Alumno NuevoDinamico = new Alumno(Nuevo.getNc(), Nuevo.getNom(), 
                                                     Nuevo.getDom(), Nuevo.getTel(), Nuevo.getEmail());
                    LCD.insertar(NuevoDinamico);
                    break;
                    
                case 2:
                    System.out.println("Eliminar alumnos");
                    if (LCE.listaVacia() && LCD.listaVacia()) {
                        System.out.println("Ambas listas vacías");
                    } else {
                        System.out.println("Escriba el numero de control ");
                        String EB = s.next();
                        
                        if (!LCE.listaVacia()) {
                            LCE.eliminar(EB);
                        }
                        if (!LCD.listaVacia()) {
                            LCD.eliminar(EB);
                        }
                    }
                    break;
                    
                case 3:
                    System.out.println("Modificar alumnos");
                    System.out.println("Escriba el numero de control");
                    String nc = s.next();
                    
                    int indiceEstatica = LCE.buscar(nc);
                    Alumno dinamico = LCD.buscar(nc);
                    
                    if (indiceEstatica == -1 && dinamico == null) {
                        System.out.println("Numero de control no existe");
                    } else {
                        Alumno nuevosDatos = new Alumno();
                        nuevosDatos.setNc(nc);
                        
                        System.out.println("Nombre Correcto");
                        nuevosDatos.setNom(s.next());
                        System.out.println("Domicilio Correcto");
                        nuevosDatos.setDom(s.next());
                        System.out.println("Telefono Correcto");
                        nuevosDatos.setTel(s.next());
                        System.out.println("Email correcto");
                        nuevosDatos.setEmail(s.next());
                        
                        if (indiceEstatica != -1) {
                            LCE.modificar(nc, nuevosDatos);
                        }
                        if (dinamico != null) {
                            LCD.modificar(nc, nuevosDatos);
                        }
                    }
                    break;
                    
                case 4:
                    System.out.println("Buscar alumnos");
                    System.out.println("Numero de control a buscar: ");
                    String EB4 = s.next();
                    
                    boolean encontrado = false;
                    
                    int indiceEst = LCE.buscar(EB4);
                    if (indiceEst != -1) {
                        System.out.println("El numero de control si existe");
                        encontrado = true;
                    }
                    
                    Alumno din = LCD.buscar(EB4);
                    if (din != null) {
                        System.out.println("El numero de control si existe");
                        encontrado = true;
                    }
                    
                    if (!encontrado) {
                        System.out.println("El numero de control no existe");
                    }
                    break;
                    
                case 5:
                    System.out.println("Consultar alumnos - Horario");
                    if (!LCE.listaVacia()) {
                        LCE.listarHorario();
                    }
                    if (!LCD.listaVacia()) {
                        LCD.listarHorario();
                    }
                    if (LCE.listaVacia() && LCD.listaVacia()) {
                        System.out.println("Ambas listas están vacías");
                    }
                    break;
                    
                case 6:
                    System.out.println("Consultar alumnos - Antihorario");
                    if (!LCE.listaVacia()) {
                        LCE.listarAntihorario();
                    }
                    if (!LCD.listaVacia()) {
                        LCD.listarAntihorario();
                    }
                    if (LCE.listaVacia() && LCD.listaVacia()) {
                        System.out.println("Ambas listas están vacías");
                    }
                    break;
            }
        }
    }
}