
package _20630306_arboles;

/**
 *
 * @author fdogs
 */
   public class NodoArbol {
    int dato;
    String nombre;
    NodoArbol hijoIzquierdo;
    NodoArbol hijoDerecho;

        public NodoArbol(int d, String nom) {
        this.dato = d;
        this.nombre = nom;
        this.hijoIzquierdo = null;
        this.hijoDerecho = null;
                    }

    public String toString() {
        return nombre + " el dato es " + dato;
    }
}