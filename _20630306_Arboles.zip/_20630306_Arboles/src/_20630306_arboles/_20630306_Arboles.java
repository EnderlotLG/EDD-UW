
package _20630306_arboles;

/**
 *
 * @author fdogs
 */
import javax.swing.JOptionPane;

public class _20630306_Arboles {

    public static void main(String[] args) {
        int opcion = 0, elemento;
        String nombre;
        ArbolBinario arbolito = new ArbolBinario();

        do {
            try {
                opcion = Integer.parseInt(JOptionPane.showInputDialog(null,
                        "1. Agregar un Nodo\n"
                        + "2. Recorrer el Árbol InOrden\n"
                        + "3. Recorrer el Árbol PreOrden\n"
                        + "4. Recorrer el Árbol PostOrden\n"
                        + "5. Buscar un Nodo\n"
                        + "6. Eliminar un Nodo\n"
                        + "7. Salir\n"
                        + "Elige una opción...", "Árboles Binarios", JOptionPane.QUESTION_MESSAGE));

                switch (opcion) {
                    case 1:
                        elemento = Integer.parseInt(JOptionPane.showInputDialog(null,
                                "Ingresa el Número del Nodo", "Agregando Nodo", JOptionPane.QUESTION_MESSAGE));
                        nombre = JOptionPane.showInputDialog(null,
                                "Ingresa el Nombre del Nodo", "Agregando Nodo", JOptionPane.QUESTION_MESSAGE);
                        arbolito.agregarNodo(elemento, nombre);
                        break;
                    case 2:
                        if (!arbolito.estaVacio()) {
                            System.out.println();
                            arbolito.inOrden(arbolito.raiz);
                        } else {
                            JOptionPane.showMessageDialog(null, "El Árbol está vacío", "Cuidado!", JOptionPane.INFORMATION_MESSAGE);
                        }
                        break;
                    case 3:
                        if (!arbolito.estaVacio()) {
                            System.out.println();
                            arbolito.preOrden(arbolito.raiz);
                        } else {
                            JOptionPane.showMessageDialog(null, "El Árbol está vacío", "Cuidado!", JOptionPane.INFORMATION_MESSAGE);
                        }
                        break;
                    case 4:
                        if (!arbolito.estaVacio()) {
                            System.out.println();
                            arbolito.postOrden(arbolito.raiz);
                        } else {
                            JOptionPane.showMessageDialog(null, "El Árbol está vacío", "Cuidado!", JOptionPane.INFORMATION_MESSAGE);
                        }
                        break;
                    case 5:
                        if (!arbolito.estaVacio()) {
                            elemento = Integer.parseInt(JOptionPane.showInputDialog(null,
                                    "Ingresa el Número del Nodo buscado", "Buscando Nodo", JOptionPane.QUESTION_MESSAGE));
                            
                            NodoArbol encontrado = arbolito.buscarNodo(elemento);
                            if (encontrado == null) {
                                JOptionPane.showMessageDialog(null, "El Nodo no se encuentra en el Árbol", "Nodo no encontrado", JOptionPane.INFORMATION_MESSAGE);
                            } else {
                                JOptionPane.showMessageDialog(null, "Nodo encontrado, sus datos son: " + encontrado, "Nodo encontrado", JOptionPane.INFORMATION_MESSAGE);
                            }
                        } else {
                            JOptionPane.showMessageDialog(null, "El Árbol está vacío", "Cuidado!", JOptionPane.INFORMATION_MESSAGE);
                        }
                        break;
                    case 6:
                        if (!arbolito.estaVacio()) {
                            elemento = Integer.parseInt(JOptionPane.showInputDialog(null,
                                    "Ingresa el Número del Nodo a Eliminar", "Eliminando Nodo", JOptionPane.QUESTION_MESSAGE));
                            
                                  if (arbolito.eliminar(elemento) == false) {
                                JOptionPane.showMessageDialog(null, "El Nodo no se encuentra en el Árbol", "Nodo no encontrado", JOptionPane.INFORMATION_MESSAGE);
                            } else {
                                JOptionPane.showMessageDialog(null, "El Nodo ha sido eliminado del Árbol", "Nodo Eliminado", JOptionPane.INFORMATION_MESSAGE);
                            }
                        } else {
                            JOptionPane.showMessageDialog(null, "El Árbol está vacío", "Cuidado!", JOptionPane.INFORMATION_MESSAGE);
                        }
                        break;
                           case 7:
                        JOptionPane.showMessageDialog(null, "Aplicación Finalizada", "Fin", JOptionPane.INFORMATION_MESSAGE);
                        break;
                            default:
                        JOptionPane.showMessageDialog(null, "Opción Incorrecta", "Cuidado!", JOptionPane.INFORMATION_MESSAGE);
                }
              } catch (NumberFormatException n) {
                JOptionPane.showMessageDialog(null, "Error " + n.getMessage());
            }
             } while (opcion != 7);
    }
}

