package proyecto.pkg1;

/**
 * Clase Alumno - utilizada en la agenda
 */
public class Alumno {
    private String Nc;
    private String Nom;
    private String Dom;
    private String Tel;
    private String Email;

    // Constructor con parámetros
    public Alumno(String Nc, String Nom, String Dom, String Tel, String Email) {
        this.Nc = Nc;
        this.Nom = Nom;
        this.Dom = Dom;
        this.Tel = Tel;
        this.Email = Email;
    }

    // Constructor vacío
    public Alumno() {
        this.Nc = "*";
        this.Nom = "";
        this.Dom = "";
        this.Tel = "";
        this.Email = "";
    }

    // Getters
    public String getNC() {
        return Nc;
    }

    public String getNom() {
        return Nom;
    }

    public String getDom() {
        return Dom;
    }

    public String getTel() {
        return Tel;
    }

    public String getEmail() {
        return Email;
    }

    // Setters
    public void setNC(String Nc) {
        this.Nc = Nc;
    }

    public void setNom(String Nom) {
        this.Nom = Nom;
    }

    public void setDom(String Dom) {
        this.Dom = Dom;
    }

    public void setTel(String Tel) {
        this.Tel = Tel;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }
}
