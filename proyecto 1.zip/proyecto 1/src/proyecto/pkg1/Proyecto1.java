package proyecto.pkg1;

import java.util.Scanner;

/**
 *
 * @author fdogs Implementación de una agenda utilizando un tipo de dato
 * abstracto Alumno utilizando memoria estática
 */
public class Proyecto1 {

    public static Scanner leer = new Scanner(System.in);
    public static Alumno[] Agenda = new Alumno[10];

    public static void Inicializar() {
        Alumno a = new Alumno("", "", "", "", "*");
        for (int j = 0; j < 10; j++) {
            Agenda[j] = new Alumno("", "", "", "", "*");
        }
    }

    public static int Indice() {
        int Pos = -1;

        for (int j = 0; j < 10; j++) {
            if (Agenda[j].getNC().equals("*")) {
                Pos = j;
                j = 10;
            }
        }
        return Pos;
    }

    public static void Agregar() {
        System.out.println("Agrega alumnos");
        int i = Indice();
        if (i == -1) {
            System.out.println("Arreglo lleno");
        } else {
            System.out.println("Escribe el numero de control: ");
            Agenda[i].setNC(leer.next());
            System.out.println("Escibre el nombre: ");
            Agenda[i].setNom(leer.next());
            System.out.println("Escribe el domicilio: ");
            Agenda[i].setDom(leer.next());
            System.out.println("Escirbe el numero de telefono: ");
            Agenda[i].setTel(leer.next());
            System.out.println("Escribe tu Email: ");
            Agenda[i].setEmail(leer.next());
        }
    }

    public static void Eliminar() {
        System.out.println("Eliminar alumnos");
        System.out.println("Escriba el numero de control ");
        int b = Buscar(leer.next());
        if (b == -1) {
            System.out.println("Numero de control no existe");
        } else {
            Agenda[b] = new Alumno("", "", "", "", "*");
        }
    }

    public static void Modificar() {
        System.out.println("Modificar alumnos");
        System.out.println("Escriba el numero de control");
        int b = Buscar(leer.next());
        if (b == -1) {
            System.out.println("Numero de control no existe");
        } else {
            int op = 0;
            while (op != 5) {
                System.out.println("Selecionar campo a modificar");
                System.out.println("1. Nombre 2. domicilio 3. Telefono 4. Email 5. Salir");
                op = leer.nextInt();
                switch (op) {
                    case 1:
                        System.out.println("Nombre Correcto");
                        Agenda[b].setNom(leer.next());
                        break;

                    case 2:
                        System.out.println("Domicilio Correcto");
                        Agenda[b].setDom(leer.next());
                        break;

                    case 3:
                        System.out.println("Telefono Correcto");
                        Agenda[b].setTel(leer.next());
                        break;

                    case 4:
                        System.out.println("Email correcto");
                        Agenda[b].setEmail(leer.next());
                        break;

                }
            }

        }
    }

    public static int Buscar(String EB) {
        if (EB.equals("*")) {
            System.out.println("Buscar alumnos");
            System.out.println("Numero de control a buscar: ");
            EB = leer.next();
        }
        int Pos = -1;

        for (int j = 0; j < 10; j++) {
            if (Agenda[j].getNC().equals(EB)) {
                Pos = j;
                j = 10;
            }
        }
        return Pos;
    }

    public static void Consultar() {
        System.out.println("Consultar alumnos");
        for (int j = 0; j < 10; j++) {
            System.out.print(j + "\t");
            System.out.print(Agenda[j].getNC() + "\t");
            System.out.print(Agenda[j].getNom() + "\t");
            System.out.print(Agenda[j].getDom() + "\t");
            System.out.print(Agenda[j].getTel() + "\t");
            System.out.println(Agenda[j].getEmail() + "\t");
        }
    }

    public static void main(String[] args) {
        int op = 0;
        Inicializar();
        while (op != 6) {
            System.out.println("1. Agrega 2.Elimina 3.Modifica 4.Busca 5.Consulta 6.Salir");
            op = leer.nextInt();
            switch (op) {
                case 1:
                    Agregar();
                    break;
                case 2:
                    Eliminar();
                    break;
                case 3:
                    Modificar();
                    break;
                case 4:
                    if (Buscar("+") == -1) {
                        System.out.println("El numero de control no existe");
                    } else {
                        System.out.println("El numero de control si existe");
                    }
                    break;
                case 5:
                    Consultar();
                    break;
            }
        }
    }
}
