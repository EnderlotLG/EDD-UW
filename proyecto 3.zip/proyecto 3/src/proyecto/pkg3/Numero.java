
package proyecto.pkg3;

/**
 *
 * @author fdogs
 * la clase Numero utilizada en el ordenamiento con memoria estática
 * Equivalente a la clase Alumno pero para números como el proyecto 1
 */
public class Numero {
    private int valor;
    private String estado;
    
    // Constructor con parámetros
    public Numero(int valor, String estado) {
        this.valor = valor;
        this.estado = estado;
    }
    
    // Constructor vacío
    public Numero() {
        this.valor = -999;
        this.estado = "*";
    }
    
    // Getters
    public int getValor() {
        return valor;
    }
    
    public String getEstado() {
        return estado;
    }
    
    // Setters
    public void setValor(int valor) {
        this.valor = valor;
    }
    
    public void setEstado(String estado) {
        this.estado = estado;
    }
}