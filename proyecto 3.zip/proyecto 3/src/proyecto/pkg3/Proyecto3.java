
package proyecto.pkg3;

/**
 *
 * @author fdogs
 * Implementación de ordenamiento de 10 números utilizando un tipo de dato
 *  utilizando memoria estática y aregllos 
 */
import java.util.Scanner;

public class Proyecto3 {

    public static Scanner leer = new Scanner(System.in);
    public static Numero[] Arreglo = new Numero[10];

    public static void Inicializar() {
        for (int j = 0; j < 10; j++) {
            Arreglo[j] = new Numero(-999, "*");
        }
    }

    public static int Indice() {
        int Pos = -1;

        for (int j = 0; j < 10; j++) {
            if (Arreglo[j].getEstado().equals("*")) {
                Pos = j;
                j = 10;
            }
        }
        return Pos;
    }

    public static void Agregar() {
        System.out.println("Agrega numeros");
        int i = Indice();
        if (i == -1) {
            System.out.println("Arreglo lleno");
        } else {
            System.out.println("Escribe el numero: ");
            int num = leer.nextInt();
            Arreglo[i].setValor(num);
            Arreglo[i].setEstado("ocupado");
        }
    }

    public static void Eliminar() {
        System.out.println("Eliminar numeros");
        System.out.println("Escriba el numero a eliminar: ");
        int b = Buscar(leer.nextInt());
        if (b == -1) {
            System.out.println("Numero no existe");
        } else {
            Arreglo[b] = new Numero(-999, "*");
        }
    }

    public static void Modificar() {
        System.out.println("Modificar numeros");
        System.out.println("Escriba el numero a modificar:");
        int b = Buscar(leer.nextInt());
        if (b == -1) {
            System.out.println("Numero no existe");
        } else {
            System.out.println("Ingrese el nuevo valor:");
            int nuevoValor = leer.nextInt();
            Arreglo[b].setValor(nuevoValor);
        }
    }

    public static int Buscar(int EB) {
        if (EB == -1) {
            System.out.println("Buscar numeros");
            System.out.println("Numero a buscar: ");
            EB = leer.nextInt();
        }
        int Pos = -1;

        for (int j = 0; j < 10; j++) {
            if (Arreglo[j].getValor() == EB && !Arreglo[j].getEstado().equals("*")) {
                Pos = j;
                j = 10;
            }
        }
        return Pos;
    }

    public static void Consultar() {
        System.out.println("Consultar numeros");
        for (int j = 0; j < 10; j++) {
            System.out.print(j + "\t");
            if (Arreglo[j].getEstado().equals("*")) {
                System.out.print("[vacío]");
            } else {
                System.out.print(Arreglo[j].getValor());
            }
            System.out.println("\t" + Arreglo[j].getEstado());
        }
    }

    public static void Ordenar() {
        System.out.println("Ordenar numeros");
        
        // Algoritmo burbuja
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9 - i; j++) {
                if (!Arreglo[j].getEstado().equals("*") && !Arreglo[j + 1].getEstado().equals("*")) {
                    if (Arreglo[j].getValor() > Arreglo[j + 1].getValor()) {
                        // Intercambiar
                        int tempValor = Arreglo[j].getValor();
                        String tempEstado = Arreglo[j].getEstado();
                        
                        Arreglo[j].setValor(Arreglo[j + 1].getValor());
                        Arreglo[j].setEstado(Arreglo[j + 1].getEstado());
                        
                        Arreglo[j + 1].setValor(tempValor);
                        Arreglo[j + 1].setEstado(tempEstado);
                    }
                }
            }
        }
        System.out.println("Numeros ordenados");
    }

    public static void main(String[] args) {
        int op = 0;
        Inicializar();
        
        while (op != 7) {
            System.out.println("1. Agrega 2. Elimina 3. Modifica 4. Busca 5. Consulta 6. Ordenar 7. Salir");
            op = leer.nextInt();
            switch (op) {
                case 1:
                    Agregar();
                    break;
                case 2:
                    Eliminar();
                    break;
                case 3:
                    Modificar();
                    break;
                case 4:
                    if (Buscar(-1) == -1) {
                        System.out.println("El numero no existe");
                    } else {
                        System.out.println("El numero si existe");
                    }
                    break;
                case 5:
                    Consultar();
                    break;
                case 6:
                    Ordenar();
                    break;
            }
        }
    }
}