
package proyecto2;

import java.util.Scanner;

/**
 *
 * @author fdogs
 * Implementación de una agenda utilizando un tipo de dato abstracto Alumno
 * utilizando memoria  dinamica 
 */
public class Proyecto2 {
   public static Scanner s = new Scanner(System.in);
    public static Alumno Agenda = new Alumno();

    public static void Inicializar() {
        //inicializa la lista de TDAS
        Agenda  = null;
    }

    public static Alumno Indice(String EB) {
        //Busca la pocision del ultimo nodo de lista (ANT)ultimo nodo de la lista 
        Alumno Pos = Agenda;
        Alumno Ant = null;
        boolean esta = false;

        while (Pos != null && !esta) {
            if (Pos.getNc().equals(EB)) {
                esta = true;
            }
            if (!esta) {
                Ant = Pos;
                Pos = Pos.getPtr();
            }
        }

        return Ant;
    }

    public static void Agregar() {
        System.out.println("Agrega alumnos");
        Alumno i = Indice("+");
        Alumno Nuevo = new Alumno("", "", "", "", "*", null);
            System.out.println("Escribe el numero de control: ");
            Nuevo.setNc(s.next());
            System.out.println("Escibre el nombre: ");
            Nuevo.setNom(s.next());
            System.out.println("Escribe el domicilio: ");
            Nuevo.setDom(s.next());
            System.out.println("Escirbe el numero de telefono: ");
            Nuevo.setTel(s.next());
            System.out.println("Escribe tu Email: ");
            Nuevo.setEmail(s.next());
            
            if(Agenda == null){ //No hay Elemntos Guardados  esta lista vacia 
               Agenda = Nuevo;
            }else{
            i.setPtr(Nuevo);
            }
        
    }


    public static void Modificar() {
        System.out.println("Modificar alumnos");
        System.out.println("Escriba el numero de control");
         Alumno b = Buscar(s.next());
        if (b == null) {
            System.out.println("Numero de control no existe");
        } else{
            int op = 0;
            while (op !=5){
            System.out.println("Selecionar campo a modificar");
            System.out.println("1. Nombre 2. domicilio 3. Telefono 4. Email 5. Salir");
            op = s.nextInt();
            switch (op){
                case 1:
                        System.out.println("Nombre Correcto");
                        b.setNom(s.next());
                        break;

                    case 2:
                        System.out.println("Domicilio Correcto");
                        b.setDom(s.next());
                        break;

                    case 3:
                        System.out.println("Telefono Correcto");
                        b.setTel(s.next());
                        break;

                    case 4:
                        System.out.println("Email correcto");
                        b.setEmail(s.next());
                        break;
                    
            }
        }
        
       }
    }
        

    public static Alumno Buscar(String EB) {
        if (EB.equals("+")) {
            System.out.println("Buscar alumnos");
            System.out.println("Numero de control a buscar: ");
            EB = s.next();
        }

        Alumno Pos = Agenda;
        boolean esta = false;
        while (Pos != null && !esta) {
            if (Pos.getNc().equals(EB)) {
                esta = true;
            }
            if (!esta) {
                Pos = Pos.getPtr();
            }
        }
        return Pos;
    }

    public static void Consultar() {
        System.out.println("Consultar alumnos");
        Alumno Pos = Agenda;
        if (Pos == null) {
            System.out.println("la lista esta vacia");
        } else {
            while (Pos != null) {
                System.out.print(Pos.getNc() + "\t");
                System.out.print(Pos.getNom() + "\t");
                System.out.print(Pos.getDom() + "\t");
                System.out.print(Pos.getTel() + "\t");
                System.out.println(Pos.getEmail() + "\t");
                Pos = Pos.getPtr();
            }
        }

    }
    
    public static void Eliminar() {
        System.out.println("Eliminar alumnos");
        if (Agenda == null) {
            System.out.println("Lista Vacia");
        } else {
            System.out.println("Escriba el numero de control ");
            String EB = s.next();
            Alumno b = Indice(EB);
            if (b == null && EB.equals(Agenda.getNc())) {
                Agenda = Agenda.getPtr();
            } else {
                /*Alumno Siguiente = b.getPtr();
                if (Siguiente != null) {
                    b.setPtr(b.getPtr().getPtr());
                } else {
                    System.out.println("El nc no existe"); 
                }*/
                
                
                if (b.getPtr() != null) {
                    b.setPtr(b.getPtr().getPtr());
                } else {
                    System.out.println("El nc no existe");
                }

            }

        }
    }

    public static void main(String[] args) {
        int op = 0;
        Inicializar();
        while (op != 6) {
            System.out.println("1. Agrega 2.Elimina 3.Modifica 4.Busca 5.Consulta 6.Salir");
            op = s.nextInt();
            switch (op) {
                case 1:
                    Agregar();
                    break;
                case 2:
                   Eliminar();
                    break;
                case 3:
                    Modificar();
                    break;
                case 4:
                    if (Buscar("+") == null) {
                        System.out.println("El numero de control no existe");
                    } else {
                        System.out.println("El numero de control si existe");
                    }
                    break;
                case 5:
                    Consultar();
                    break;
            }
        }
    }
}
