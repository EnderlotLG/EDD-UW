
package proyecto3.pkg1;

/**
 *
 * @author fdogs
 * * Clase Numero - utilizada en el ordenamiento con memoria dinámica
 * Equivalente a la clase Alumno pero para números con punteros
 */
public class Numero {
     private int valor;
    private String estado;
    private Numero ptr;
    
    // Constructor con parámetros
    public Numero(int valor, String estado, Numero ptr) {
        this.valor = valor;
        this.estado = estado;
        this.ptr = ptr;
    }
    
    // Constructor vacío
    public Numero() {
        this.valor = -999;
        this.estado = "*";
        this.ptr = null;
    }
    
    // Getters
    public int getValor() {
        return valor;
    }
    
    public String getEstado() {
        return estado;
    }
    
    public Numero getPtr() {
        return ptr;
    }
    
    // Setters
    public void setValor(int valor) {
        this.valor = valor;
    }
    
    public void setEstado(String estado) {
        this.estado = estado;
    }
    
    public void setPtr(Numero ptr) {
        this.ptr = ptr;
    }
}
