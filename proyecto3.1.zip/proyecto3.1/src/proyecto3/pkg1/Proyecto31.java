
package proyecto3.pkg1;

/*
 *
 * @author fdogs
 * Implementación de ordenamiento de números utilizando un tda
 * en los numero utilizando memoria dinámica con punteros
 */
import java.util.Scanner;

public class Proyecto31 {
    public static Scanner s = new Scanner(System.in);
    public static Numero Lista = new Numero();

    public static void Inicializar() {
        //inicializa la lista de TDA con punteros
        Lista = null;
    }

    public static Numero Indice(String EB) {
        //Busca la posición del ultimo nodo de lista (ANT)ultimo nodo de la lista 
        Numero Pos = Lista;
        Numero Ant = null;
        boolean esta = false;

        while (Pos != null && !esta) {
            if (String.valueOf(Pos.getValor()).equals(EB)) {
                esta = true;
            }
            if (!esta) {
                Ant = Pos;
                Pos = Pos.getPtr();
            }
        }

        return Ant;
    }

    public static void Agregar() {
        System.out.println("Agrega numeros");
        Numero i = Indice("+");
        Numero Nuevo = new Numero(-999, "*", null);
        System.out.println("Escribe el numero: ");
        int num = s.nextInt();
        Nuevo.setValor(num);
        Nuevo.setEstado("Pos ocupada");
        
        if(Lista == null){ //No hay Elementos Guardados, esta lista vacia 
           Lista = Nuevo;
        } else {
           i.setPtr(Nuevo);
        }
    }

    public static void Modificar() {
        System.out.println("Modificar numeros");
        System.out.println("Escriba el numero a modificar:");
        Numero b = Buscar(s.nextInt());
        if (b == null) {
            System.out.println("Numero no existe");
        } else {
            System.out.println("Ingrese el nuevo valor:");
            int nuevoValor = s.nextInt();
            b.setValor(nuevoValor);
        }
    }

    public static Numero Buscar(int EB) {
        if (EB == -1) {
            System.out.println("Buscar numeros");
            System.out.println("Numero a buscar: ");
            EB = s.nextInt();
        }

        Numero Pos = Lista;
        boolean esta = false;
        while (Pos != null && !esta) {
            if (Pos.getValor() == EB) {
                esta = true;
            }
            if (!esta) {
                Pos = Pos.getPtr();
            }
        }
        return Pos;
    }

    public static void Consultar() {
        System.out.println("Consultar numeros");
        Numero Pos = Lista;
        if (Pos == null) {
            System.out.println("La lista está vacia");
        } else {
            while (Pos != null) {
                System.out.print(Pos.getValor() + "\t");
                System.out.println(Pos.getEstado() + "\t");
                Pos = Pos.getPtr();
            }
        }
    }
    
    public static void Eliminar() {
        System.out.println("Eliminar numeros");
        if (Lista == null) {
            System.out.println("Lista Vacia");
        } else {
            System.out.println("Escriba el numero a eliminar: ");
            int EB = s.nextInt();
            Numero b = Indice(String.valueOf(EB));
            
            if (b == null && EB == Lista.getValor()) {
                Lista = Lista.getPtr();
            } else {
                if (b != null && b.getPtr() != null) {
                    b.setPtr(b.getPtr().getPtr());
                } else {
                    System.out.println("El numero no existe");
                }
            }
        }
    }

    public static void Ordenar() {
        System.out.println("Ordenar numeros");
        
        if (Lista == null) {
            System.out.println("Lista vacia");
            return;
        }
        
        // Ordenamiento con el metodo de la burbuja directa en la lista enlazada
        boolean intercambio;
        do {
            intercambio = false;
            Numero actual = Lista;
            
            while (actual != null && actual.getPtr() != null) {
                if (actual.getValor() > actual.getPtr().getValor()) {
                    // Intercambiar los valores
                    int temp = actual.getValor();
                    actual.setValor(actual.getPtr().getValor());
                    actual.getPtr().setValor(temp);
                    intercambio = true;
                }
                actual = actual.getPtr();
            }
        } while (intercambio);
        
        System.out.println("Numeros ordenados");
    }

    public static void main(String[] args) {
        int op = 0;
        Inicializar();
        
        while (op != 7) {
            System.out.println("1. Agrega 2. Elimina 3. Modifica 4. Busca 5. Consulta 6. Ordenar 7. Salir");
            op = s.nextInt();
            switch (op) {
                case 1:
                    Agregar();
                    break;
                case 2:
                   Eliminar();
                    break;
                case 3:
                    Modificar();
                    break;
                case 4:
                    if (Buscar(-1) == null) {
                        System.out.println("El numero no existe");
                    } else {
                        System.out.println("El numero si existe");
                    }
                    break;
                case 5:
                    Consultar();
                    break;
                case 6:
                    Ordenar();
                    break;
            }
        }
    }
}