
package proyecto5;
//Implementacion de solucion recursiva de numeros enteros comprendidos a n

import java.util.*;

public class Recursividad {

    /**
     * Proyecto 5
     * @author fdogs
     */
    static Scanner sc = new Scanner(System.in);
    /*
    5! = 5*4*3*2*1           5! = 5*4     n! = n* n-1! funcion recursiva
    4! = 4*3*2*1             4! = 4*3
    3! = 3*2*1               3! = 3*2
    2! = 2*1                 2! = 2*1
    1! = 1   
    
    Fibonacci(N) = Fibonacci(N-1) + Fibonacci(N-2)
    F(3) = 2+1
    0 1 1 2 3 5 8 13 21 34 55 ....
    */
    public static void FibonacciIterativo(int n){
    int n1 = 0;
    int n2 = 0;
    int n3 = 0;
    if(n>1){
        System.out.print(n1 + ", "+ n2 +", ");
    }else if (n == 1){
         System.out.print(n1 + ", ");
    }
        for(int j=0; j<n-1; j++){
        n3 = n1 + n2;
        System.out.print(n3);
        if(j<n-3)System.out.println(", ");
        n1 = n2;
        n2 = n3;
        }
        System.out.println("");
          }
       
    
    public static int FiboRec(int n) {
        if (n <= 1) {
            return n;
        } else {
            return FiboRec(n - 1) + FiboRec(n - 2);
        }

    }
    
    
    public static void FibonacciRecursivo(int n){
    for (int j = 0; j < n; j++){
        System.out.print(FiboRec(j) + ", ");
       }
        System.out.println("");
    }
    
    
    public static long FactorialIteractivo(int n) {
        long f = 1;
        for (int i = n; i > 0; i--) {
            f*=i;
        }
       return f;
    }
    
    public static long FactorialRecursivo(int n){
    if (n==1) return 1;
    else return n* FactorialRecursivo(n-1);
    }

    public static int SumaIterativa(int n) {
        int suma = 0;
        for (int i = n; i > 0; i--) {
            //suma = suma + i
            suma += i;
        }
        return suma;

    }

    public static int SumaRecursiva(int n) {
        if (n == 1) return 1;
         else return n + SumaRecursiva(n - 1);
        
    }

    public static void main(String[] args) {
        System.out.println("Proporcione el valor de n");
        int n = sc.nextInt();
        long tiempoInicio = System.nanoTime();
        System.out.println("El fibonacci iteractivo" + n + " elemntos es " );
        FibonacciIterativo(n);
        long tiempofinal = System.nanoTime();
        long TotalIterativo = tiempofinal - tiempoInicio;
        tiempoInicio=System.nanoTime();
        System.out.println("El Fibonacci recursivo de los enteros comprendidos en " + n + " es " );
        FibonacciRecursivo(n);
        tiempofinal = System.nanoTime();
       long TotalRecursivo = tiempofinal - tiempoInicio;
       if(TotalIterativo < TotalRecursivo){
           System.out.println("El Iterativo es mas eficiente ");
       } else {
           System.out.println("El recursivo es mas eficiente");
       }
       
        System.out.println("Tiempo total iterativo "+TotalIterativo);
        System.out.println("Tiempo total recursivo "+TotalRecursivo);
    }

}
