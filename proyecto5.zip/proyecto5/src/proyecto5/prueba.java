/*
 * @author fdogs
 */
package proyecto5;

import java.util.*;
import javax.swing.JOptionPane;

public class prueba {

    public static Scanner sc = new Scanner(System.in);

    public static prueba2 lista = null;
    public static int contador = 0;
    public static int[] numeros = new int[10]; // Para el método burbuja
    public static prueba2 listaNumeros = null; // Para el método de lista

    public static void main(String[] args) {
        int op = 0;
        boolean numerosAgregados = false;

        while (op != 3) {
            System.out.println("\n1. Agregar  2. Consultar  3. Salir");
            op = sc.nextInt();
            sc.nextLine(); // limpiar buffer

            switch (op) {
                case 1:
                    // Reiniciar lista y contador cada vez que se agreguen nuevos números
                    listaNumeros = null;
                    contador = 0;

                    // Leer los 10 números para ambos métodos
                    for (int i = 0; i < 10; i++) {
                        int num = Integer.parseInt(JOptionPane.showInputDialog("Digite el numero " + (i + 1) + ":"));
                        numeros[i] = num; // Guardar para método burbuja
                        agregarNumeroLista(num); // Guardar para método lista
                    }
                    numerosAgregados = true;
                    System.out.println("10 números agregados correctamente");
                    break;

                case 2:
                    if (!numerosAgregados) {
                        System.out.println("Primero debe agregar números (Opción 1)");
                        break;
                    }

                    // Ejecutar y comparar ambos métodos
                    System.out.println("\n=== COMPARACIÓN DE MÉTODOS ===");

                    // Método burbuja con array
                    long tiempoInicio = System.nanoTime();
                    ejecutarMetodoBurbuja();
                    long tiempoFinal = System.nanoTime();
                    long TotalBurbuja = tiempoFinal - tiempoInicio;

                    // Método con lista enlazada
                    tiempoInicio = System.nanoTime();
                    mostrarListaOrdenada();
                    tiempoFinal = System.nanoTime();
                    long TotalLista = tiempoFinal - tiempoInicio;

                    // Resultados
                    if (TotalBurbuja < TotalLista) {
                        System.out.println("El metodo BURBUJA es mas eficiente");
                    } else {
                        System.out.println("El metodo con LISTA ENLAZADA es mas eficiente");
                    }
                    System.out.println("Tiempo Burbuja: " + TotalBurbuja + " ns");
                    System.out.println("Tiempo Lista: " + TotalLista + " ns");
                    break;

                case 3:
                    System.out.println("Adios");
                    break;

                default:
                    System.out.println("Opcion no valida");
                    break;
            }
        }
    }

    // Agregar número a la lista (ordenadamente)
    public static void agregarNumeroLista(int val) {
        prueba2 Nuevo = new prueba2(val, null);

        if (listaNumeros == null) {
            listaNumeros = Nuevo;
        } else {
            prueba2 iPtr = listaNumeros;
            prueba2 Ant = null;
            boolean encontrado = false;

            while (iPtr != null && !encontrado) {
                if (val < iPtr.getValor()) {
                    encontrado = true;
                }
                if (!encontrado) {
                    Ant = iPtr;
                    iPtr = iPtr.getPtr();
                }
            }

            if (Ant == null) {
                Nuevo.setPtr(listaNumeros);
                listaNumeros = Nuevo;
            } else {
                Nuevo.setPtr(Ant.getPtr());
                Ant.setPtr(Nuevo);
            }
        }
        contador++;
    }

    // MÉTODO BURBUJA CON ARRAY
    public static void ejecutarMetodoBurbuja() {
        int aux;
        for (int i = 0; i < numeros.length; i++) {
            for (int j = 0; j < numeros.length - 1; j++) {
                if (numeros[j] > numeros[j + 1]) {
                    aux = numeros[j];
                    numeros[j] = numeros[j + 1];
                    numeros[j + 1] = aux;
                }
            }
        }
        System.out.println("Burbuja - Elementos ordenados:");
        for (int i = 0; i < 10; i++) {
            System.out.print(numeros[i] + " ");
        }
        System.out.println();
    }

    // MOSTRAR LISTA ORDENADA
    public static void mostrarListaOrdenada() {
        System.out.println("Lista - Elementos ordenados:");
        prueba2 temp = listaNumeros;
        while (temp != null) {
            System.out.print(temp.getValor() + " ");
            temp = temp.getPtr();
        }
        System.out.println();
    }
}
