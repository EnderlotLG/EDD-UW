
package proyecto5;

/**
 *
 * @author fdogs
 */
public class prueba2 {
private int valor;
    private prueba2 ptr;
    
    public prueba2(int valor, prueba2 ptr) {
        this.valor = valor;
        this.ptr = ptr;
    }
    
    public int getValor() {
        return valor;
    }
    
    public prueba2 getPtr() {
        return ptr;
    }
    
    public void setPtr(prueba2 ptr) {
        this.ptr = ptr;
    }
}